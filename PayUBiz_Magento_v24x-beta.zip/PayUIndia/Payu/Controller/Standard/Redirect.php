<?php

namespace PayUIndia\Payu\Controller\Standard;

class Redirect extends \PayUIndia\Payu\Controller\PayuAbstract {

    public function execute() {
        if (!$this->getRequest()->isAjax()) {
            $this->_cancelPayment();
            $this->checkoutSession->restoreQuote();
            $this->getResponse()->setRedirect(
                    $this->getCheckoutHelper()->getUrl('checkout')
            );
        }
		
        $html = $this->getPaymentMethod()->buildCheckoutRequest();
		
		if(isset($html['error']) && $html['error']!="") {
			//$this->_logger->error("PayU Error-".json_encode($html)); 	
			$this->messageManager->addError("<strong>Error:</strong> ".$html['error']);
		}
	
		return $this->resultJsonFactory->create()->setData(['html' => $html['data']]);
    }

}
