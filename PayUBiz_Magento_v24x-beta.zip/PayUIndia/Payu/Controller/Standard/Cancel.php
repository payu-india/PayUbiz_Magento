<?php

namespace PayUIndia\Payu\Controller\Standard;

class Cancel extends \PayUIndia\Payu\Controller\PayuAbstract {

    public function execute() {
		$paymentMethod = $this->getPaymentMethod();
        //$order=$this->getOrder();		
		//$paymentMethod->cancelOrder($order);
		$goto=$this->_cancelPayment('Payment canceld/failed...Order canceled...');
        $this->messageManager->addErrorMessage(__('Your order has been canceled'));
        $this->getResponse()->setRedirect(
                $this->getCheckoutHelper()->getUrl('checkout').'/'.$goto
        );
    }

}
