# PayUIndia_Affordability
PayUIndia_Affordability module allow to display affordability widget by PayU  and facilitate customer to check available payments offers provided by bank.

It can be configured in two ways
 - Configutation Management. Widget can be configured for the credentials and location of widget show/hinden
 - Widget Management .Widget can be shown and any page using magenmto widget features

## How to install & upgrade PayUIndia_Affordability

### 1. Install via composer (recommend)

We recommend you to install PayUIndia_Affordability module via composer. It is easy to install, update and maintaince.

Run the following command in Magento 2 root folder.

#### 1.1 Install

```
composer require PayUIndia/Affordability
php bin/magento setup:upgrade
php bin/magento setup:static-content:deploy
```

#### 1.2 Upgrade

```
composer update PayUIndia/Affordability
php bin/magento setup:upgrade
php bin/magento setup:static-content:deploy
```

Run compile if your store in Product mode:

```
php bin/magento setup:di:compile
```

### 2. Copy and paste

If you don't want to install via composer, you can use this way.

-   Download [the latest version here](https://github.com/payu-india/PayUIndia_Affordability/blob/master/PayUIndia_Affordability-v1.0.zip)
-   Extract `master.zip` file to `app/code/PayUIndia/Affordability` ; You should create a folder path `app/code/PayUIndia/Affordability` if not exist.
-   Go to Magento root folder and run upgrade command line to install `PayUIndia_Affordability`:

```
php bin/magento setup:upgrade
php bin/magento setup:static-content:deploy
```
