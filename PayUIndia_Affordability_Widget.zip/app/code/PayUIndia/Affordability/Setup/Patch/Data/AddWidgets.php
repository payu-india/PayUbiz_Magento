<?php

/**
 * PayUIndia
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the https://payu.in/ license that is
 * available through the world-wide-web at this URL:
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    PayUIndia
 * @package     PayUIndia_Affordability
 * @copyright   Copyright (c) PayUIndia (https://payu.in/)
 */

namespace PayUIndia\Affordability\Setup\Patch\Data;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\Patch\DataPatchInterface;

/**
 * Class AddWidgets for adding widgets for product and cart page
 */

class AddWidgets implements DataPatchInterface
{
   /** @var ModuleDataSetupInterface */
    private $moduleDataSetup;

   /** @var EavSetupFactory */
    private $eavSetupFactory;

    /** @var ScopeConfigInterface */
    private $scopeConfig;

    /** @var InstanceFactory */
    private $widgetFactory;

   /** @var State */
    private $state;

    /** @var StoreManagerInterface */
    private $_storeManager;

   /**
    * constructor
    * @param ModuleDataSetupInterface $moduleDataSetup
    * @param EavSetupFactory $eavSetupFactory
    * @param ScopeConfigInterface $scopeConfig
    * @param InstanceFactory $widgetFactory
    * @param State $state
    * @param StoreManagerInterface $storeManager

    */
    public function __construct(
        ModuleDataSetupInterface $moduleDataSetup,
        EavSetupFactory $eavSetupFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Widget\Model\Widget\InstanceFactory $widgetFactory,
        \Magento\Framework\App\State $state,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->moduleDataSetup = $moduleDataSetup;
        $this->eavSetupFactory = $eavSetupFactory;
        $this->scopeConfig = $scopeConfig;
        $this->widgetFactory = $widgetFactory;
        $this->state = $state;
        $this->_storeManager = $storeManager;
    }

   /**
    * @inheritdoc
    */
    public function apply()
    {
        /** @var EavSetup $eavSetup */

        $this->state->setAreaCode(\Magento\Framework\App\Area::AREA_FRONTEND);

        $eavSetup = $this->eavSetupFactory->create(['setup' => $this->moduleDataSetup]);

        $styleConfig = [
        "style_lightcolor_code"=> $this->scopeConfig->getValue('affordability/style/light_color'),
        "style_darkcolor_code"=> $this->scopeConfig->getValue('affordability/style/dark_color') ,
        "style_backgrundcolor_code"=> $this->scopeConfig->getValue('affordability/style/background_color')
        ];

        $themeId = $this->scopeConfig->getValue(
            \Magento\Framework\View\DesignInterface::XML_PATH_THEME_ID,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->_storeManager->getStore()->getId()
        );

        $affordabilityWidgetProduct = [
          'instance_type' => \PayUIndia\Affordability\Block\Widget\Affordability::class,
          'theme_id' => $themeId,
          'title' => 'Affordability widget for Product page',
          'store_ids' => $this->_storeManager->getStore()->getId(),
          'widget_parameters' => json_encode($styleConfig),
          'sort_order' => 5,
          'page_groups' => [[
            'page_group' => 'all_products',
            'all_products' => [
                'page_id' => null,
                'page_group' => 'all_products',
                'layout_handle' => 'catalog_product_view',
                'block' => 'content.bottom',
                'for' => 'all'
            ]
          ]]
        ];

        $widget = $this->widgetFactory->create()->setData($affordabilityWidgetProduct)->save();

        $affordabilityWidgetCart = [
          'instance_type' => \PayUIndia\Affordability\Block\Widget\Affordability::class,
          'theme_id' => $themeId,
          'title' => 'Affordability widget for Cart page',
          'store_ids' => $this->_storeManager->getStore()->getId(),
          'widget_parameters' => json_encode($styleConfig),
          'sort_order' => 10,
          'page_groups' => [[
            'page_group' => 'pages',
            'pages' => [
                'page_id' => null,
                'page_group' => 'pages',
                'layout_handle' => 'checkout_cart_index',
                'block' => 'content.bottom',
                'for' => 'all'
            ]
          ]]
        ];

        $widget = $this->widgetFactory->create()->setData($affordabilityWidgetCart)->save();
    }

   /**
    * @inheritdoc
    */
    public static function getDependencies()
    {
        return [];
    }

   /**
    * @inheritdoc
    */
    public function getAliases()
    {
        return [];
    }

   /**
    * @inheritdoc
    */
    public static function getVersion()
    {
        return '2.0.0';
    }
}
