<?php
/**
 * PayUIndia
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the https://payu.in/ license that is
 * available through the world-wide-web at this URL:
 * https://payu.in/
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    PayUIndia
 * @package     PayUIndia_Affordability
 * @copyright   Copyright (c) PayUIndia (https://payu.in/)
 */
namespace PayUIndia\Affordability\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use Magento\Catalog\Block\Product\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Registry;

  /**
   * @var \PayUIndia\Affordability\Block\Widget\Affordability $block
   */
class Affordability extends Template implements BlockInterface
{

    /**
     * @var \PayUIndia\Affordability\Block\Widget\Affordability
     */
    protected $_template = "PayUIndia_Affordability::widget/template.phtml";
    
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

     /**
      * @var Registry
      */
    protected $registry;

    /**
     *  constructor
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        Registry $registry,
        array $data = []
    ) {
        
        $this->scopeConfig = $scopeConfig;
        $this->registry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve the module enable or disable from the configuration.
     *
     * @return string
     */
    public function isModuleEnabled()
    {
        return $this->scopeConfig->getValue('affordability/general/active');
    }

    /**
     * Retrieve the module .
     *
     * @return string
     */
    public function isEnabledOnProductPage()
    {
        
        return $this->scopeConfig->getValue('affordability/general/active_for_product_details');
    }

     /**
      * Retrieve the current product sku.
      *
      * @return string
      */
    public function getProductSku()
    {
        $product = $this->getCurrentProduct();
       
        if ($product) {
           
            return $product->getSku();
        }
        return null;
    }
    /**
     * Retrieve the current product.
     *
     * @return product
     */
    protected function getCurrentProduct()
    {
        return $this->registry->registry('current_product');
    }
}
