<?php
/**
 * PayUIndia
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the https://payu.in/ license that is
 * available through the world-wide-web at this URL:
 * https://payu.in/
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    PayUIndia
 * @package     PayUIndia_Affordability
 * @copyright   Copyright (c) PayUIndia (https://payu.in/)
 */
namespace PayUIndia\Affordability\Block\Product;

use Magento\Catalog\Block\Product\Context;
use Magento\Framework\View\Element\Template;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Registry;

/**
 * Class Offers render the widget and provide necessary helpers
 */
class Offers extends Template
{
    
    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

     /**
      * @var Registry
      */
    protected $registry;

    /**
     * Offers constructor.
     * @param Context $context
     * @param Registry $registry
     * @param ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        
        $this->scopeConfig = $scopeConfig;
        $this->registry = $registry;
        parent::__construct($context, $data);
    }

    /**
     * Retrieve the module enable or disable from the configuration.
     *
     * @return int
     */
    public function isModuleEnabled()
    {
        return $this->scopeConfig->getValue('affordability/general/active');
    }

    /**
     * Retrieve the module enabled on product page.
     *
     * @return int
     */
    public function isEnabledOnProductPage()
    {
        return $this->scopeConfig->getValue('affordability/general/active_for_product_details');
    }

   /**
    * Retrieve if module enabled on cart
    *
    * @return int
    */
    public function isEnabledOnCartPage()
    {
        return $this->scopeConfig->getValue('affordability/general/active_for_cart');
    }

     /**
      * Retrieve the current product sku.
      *
      * @return string|null
      */
    public function getProductSku()
    {
        $product = $this->getCurrentProduct();
       
        if ($product) {
           
            return $product->getSku();
        }
        return null;
    }

    /**
     * Retrieve the current product.
     *
     * @return \Magento\Catalog\Model\Product
     */
    protected function getCurrentProduct()
    {
        return $this->registry->registry('current_product');
    }
}
