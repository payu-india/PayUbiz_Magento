<?php
/**
 * PayUIndia
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the https://payu.in/ license that is
 * available through the world-wide-web at this URL:
 * https://payu.in/
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    PayUIndia
 * @package     PayUIndia_Affordability
 * @copyright   Copyright (c) PayUIndia (https://payu.in/)
 */
namespace PayUIndia\Affordability\Controller\Widget;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Registry;

/**
 * Class Config return the json configuration for widget
 */

class Config extends Action
{
    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $jsonResultFactory;

    /**
     * @var \PayUIndia\Affordability\Helper\Data
     */
    protected $helper;

    /**
     * @var Registry
     */
    protected $registry;

    /**
     * Offers constructor.
     * @param Context $context
     * @param JsonFactory $jsonResultFactory
     * @param Registry $registry
     * @param Data $helper
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $jsonResultFactory,
        Registry $registry,
        \PayUIndia\Affordability\Helper\Data $helper
    ) {
        parent::__construct($context);
        $this->jsonResultFactory = $jsonResultFactory;
        $this->helper = $helper;
         $this->registry = $registry;
    }

    /**
     * Retrieve the configuration for widget.
     *
     * @return json
     */

    public function execute()
    {
        $type  = $sku = null;
        $params = $this->getRequest()->getParams();

        if (isset($params['type']) && $params['type']!='') {
            $type = $params['type'];
        }
        if (isset($params['sku']) && $params['sku']!='') {
            $sku = $params['sku'];
        }

        $data = $this->helper->setWidgetType($type)->getWidgetConfiguration($sku);
        $result = $this->jsonResultFactory->create();
        $result->setData($data);
        return $result;
    }
}
