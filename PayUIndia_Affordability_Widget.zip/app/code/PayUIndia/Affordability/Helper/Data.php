<?php
/**
 * PayUIndia
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the https://payu.in/ license that is
 * available through the world-wide-web at this URL:
 * https://payu.in/
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    PayUIndia
 * @package     PayUIndia_Affordability
 * @copyright   Copyright (c) PayUIndia (https://payu.in/)
 */
namespace PayUIndia\Affordability\Helper;

use Magento\Catalog\Block\Product\Context;
use Magento\Checkout\Model\Session;
use Magento\Framework\App\Config\ScopeConfigInterface;

/**
 * Class Data provide helper method for widgets
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var $widgetType
     */
    private $widgetType;

    /**
     * @var productRepository
     */
    private $productRepository;

    /**
     * @var Session
     */
    protected $checkoutSession;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var _customerSession
     */

    protected $_customerSession;

    /**
     * Data constructor
     * @param Session $checkoutSession
     * @param ScopeConfigInterface $scopeConfig
     * @param Session $customerSession
     * @param ProductRepositoryInterface $productRepository
     */
    public function __construct(
        Session $checkoutSession,
        ScopeConfigInterface $scopeConfig,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->scopeConfig = $scopeConfig;
        $this->_customerSession = $customerSession;
      
        $this->productRepository = $productRepository;
    }

    /**
     * Retrieve the merchant key from the configuration.
     *
     * @return string
     */
    public function getMerchantKey()
    {
        return $this->scopeConfig->getValue('affordability/payu/merchant_key');
    }

     /**
      * Retrieve the current product final price.
      *
      * @param string $sku
      * @return string
      */
    public function getProductAmount($sku = null)
    {
        
        if ($this->widgetType=="product") {
            if ($sku) {
                $product = $this->productRepository->get($sku);

                if ($product) {
                    return $product->getFinalPrice();
                }
            }
            return null;
            
        }

        if ($this->widgetType=="cart") {
            $subTotal = $this->checkoutSession->getQuote()->getSubtotal();
            return $subTotal;
        }
        return null;
    }
 
    /**
     * Retrieve the module enable or disable from the configuration.
     *
     * @return string
     */
    public function isModuleEnabled()
    {
        return $this->scopeConfig->getValue('affordability/general/active');
    }

    /**
     * Retrieve the module .
     *
     * @return string
     */
    public function isEnabledOnProductPage()
    {
        
        return $this->scopeConfig->getValue('affordability/general/active_for_product_details');
    }

   /**
    * Retrieve the module .
    *
    * @return string
    */
    public function isEnabledOnCartPage()
    {
        return $this->scopeConfig->getValue('affordability/general/active_for_cart');
    }

    /**
     * Retrieve the applicable sku list .
     *
     * @param string $sku
     * @return string
     */
    public function getSkuDetails($sku = null)
    {
        
        $skuDetails = [];

        if ($this->widgetType=="product") {
        
            $product = $this->productRepository->get($sku);

            if ($product) {
                $skuDetails =  [
                [
                    "skuId"=> $product->getSku(),
                    "skuAmount"=> $product->getFinalPrice(),
                    "quantity"=> 1
                ]
                ];
            }
        }

        if ($this->widgetType=="cart") {
        
            $items = $this->checkoutSession->getQuote()->getAllVisibleItems();
       
            if ($items) {
                foreach ($items as $item) {
                    $skuDetails[] =
                    [
                    "skuId"=> $item->getSku(),
                    "skuAmount"=> $item->getPrice(),
                    "quantity"=> $item->getQty()
                    ];
                }
            }
        }
        return json_encode($skuDetails);
    }

    /**
     * Retrieve the  style configuration.
     *
     * @return string
     */
    public function getStyleConfig()
    {
        
        $styleConfig = [];

        $styleConfig =  [
                "lightColor"=> $this->scopeConfig->getValue('affordability/style/light_color'),
                "darkColor"=> $this->scopeConfig->getValue('affordability/style/dark_color') ,
                "backgroundColor"=> $this->scopeConfig->getValue('affordability/style/background_color')
        ];

        return json_encode($styleConfig);
    }

    /**
     * Retrieve the user details .
     *
     * @return string
     */
    public function getUserDetails()
    {
        
        $userDetails = [];

        if ($this->_customerSession->isLoggedIn()) {
            $salt = $this->scopeConfig->getValue('affordability/general/salt');

            $phone = $this->getCustomerPhoneNUmber();

            if ($phone) {
                $key = $this->getMerchantKey()."|".$this->getProductAmount()."|".$phone."|".$salt."|".date('Y-m-d');
               
                $token = hash('sha512', $key);

                $userDetails =  [
                    [
                        "mobileNumber"=>$phone ,
                        "token"=>$token,
                        "timeStamp"=>date('D, d M Y H:i:s \G\M\T')
                    ]
                ];
            }
        }

        return json_encode($userDetails);
    }

    /**
     * Retrieve the customer number.
     *
     * @return string
     */
    public function getCustomerPhoneNUmber()
    {

        $allow_eligibiity_check = $this->scopeConfig->getValue('affordability/general/allow_eligibiity_check');
        $salt = $this->scopeConfig->getValue('affordability/general/salt');

        $phone_attribute = $this->scopeConfig->getValue('affordability/general/phone_attribute');

        if ($allow_eligibiity_check && $salt!="" && $phone_attribute) {
            $customerphone = $this->_customerSession->getCustomer()->getData($phone_attribute);
            if ($customerphone!="") {
                return $customerphone;
            }
             
        }
        
        return null;
    }
    
    /**
     * Retrieve the customer number.
     *
     * @param string $sku
     * @return string
     */
    public function getWidgetConfiguration($sku = null)
    {
        return [
            "key"=>$this->getMerchantKey(),
            "amount"=>$this->getProductAmount($sku),
            "skuDetails"=>$this->getSkuDetails($sku),
            "styleConfig"=>$this->getStyleConfig(),
            "userDetails"=>$this->getUserDetails(),
        ];
    }

    /**
     * Set widget type
     *
     * @param string $type
     */
    public function setWidgetType($type)
    {
        $this->widgetType = $type;
        return $this;
    }

     /**
      * Retrieve the current product sku.
      *
      * @return string
      */
    public function getProductSku()
    {
        $product = $this->getCurrentProduct();
       
        if ($product) {
           
            return $product->getSku();
        }
        return null;
    }

    /**
     * Retrieve the current product.
     *
     * @return string
     */
    protected function getCurrentProduct()
    {
        return $this->registry->registry('current_product');
    }
}
