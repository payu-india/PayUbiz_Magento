<?php
/**
 * PayUIndia
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the https://payu.in/ license that is
 * available through the world-wide-web at this URL:
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    PayUIndia
 * @package     PayUIndia_Affordability
 * @copyright   Copyright (c) PayUIndia (https://payu.in/)
 */

namespace PayUIndia\Affordability\Model\Config\Source\Customer;

use Magento\Framework\Option\ArrayInterface;

/**
 * Returns customer attribute list
 */

class Attributes implements ArrayInterface
{
     /**
      * @var \Magento\Eav\Model\Config
      */
    protected $eavConfig;

    /**
     * custructor
     *
     * @param \Magento\Eav\Model\Config $eavConfig
     */

    public function __construct(\Magento\Eav\Model\Config $eavConfig)
    {
        $this->eavConfig = $eavConfig;
    }

    /**
     * Return attribute array
     *
     * @return array
     */
    public function toOptionArray()
    {

        $arr = $this->toArray();
        $data = [];

        foreach ($arr as $key => $value) {

            $data[] = [
                'value' => $key,
                'label' => $value
            ];
        }

        return $data;
    }

    /**
     * Get options array
     *
     * @return array
     */
    public function toArray()
    {

        $attributes = $this->eavConfig->getEntityAttributes('customer');
         $attributesList = [];

        foreach ($attributes as $attribute) {
            
                $attributesList[$attribute->getAttributeCode()] = __($attribute->getStoreLabel());
        }

        return $attributesList;
    }
}
