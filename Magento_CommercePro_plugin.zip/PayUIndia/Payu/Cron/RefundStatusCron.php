<?php

namespace PayUIndia\Payu\Cron;

use Magento\Framework\App\Config\ScopeConfigInterface;


class RefundStatusCron
{
    protected $scopeConfig;
    protected $logger;
    protected $payuRefundFactory;
    protected $payuRefundHelper;
    protected $encrypted;

    public function __construct(
        ScopeConfigInterface $scopeConfig,
        \PayUIndia\Payu\Model\PayuRefundFactory $payuRefundFactory,
        \PayUIndia\Payu\Helper\PayuRefund $payuRefundHelper,
        \Magento\Config\Model\Config\Backend\Encrypted $encrypted
        )
    {
        $this->scopeConfig = $scopeConfig;
        $this->payuRefundFactory = $payuRefundFactory;
        $this->payuRefundHelper = $payuRefundHelper;
        $this->encrypted = $encrypted;
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/cron.log');
		$this->logger = new \Zend_Log();
		$this->logger->addWriter($writer);
    }

    public function execute()
    {

        $refund = $this->payuRefundFactory->create();
        $refundData = $refund->getCollection()->addFieldToFilter('status_code',array('neq'=>100))->getData();
        foreach($refundData as $refund){
            $mihpayid=explode('-',$refund['mihpayid']);

            $url = 'https://info.payu.in/merchant/postservice.php?form=2';
            if( $this->getConfigData('environment') == 'sandbox' )
                $url = "https://test.payu.in/merchant/postservice.php?form=2";
            $this->encrypted->processValue($this->getConfigData("merchant_key"));
            $fields = array(
                'key' => $this->encrypted->processValue($this->getConfigData("merchant_key")),
                'command' => 'check_action_status',
                'var1' => $refund['refund_txn_id'],

            );

            $hash = hash("sha512", $fields['key'].'|'.$fields['command'].'|'.$fields['var1'].'|'.$this->encrypted->processValue($this->getConfigData('salt')));
            $fields['hash'] = $hash;

            $fields_string = http_build_query($fields);
            // Curl Execution
            $response=$this->payuRefundHelper->curlExecute($url,$fields_string);

            $res=json_decode($response);

            $this->logger->info($response);
            $refundTxnId=$refund['refund_txn_id'];
            if($res->transaction_details->$refundTxnId->$refundTxnId->status=='success'){

                $updateRefund = $this->payuRefundFactory->create()->load($refund['id']);
                $updateRefund->setStatus('success');
                $updateRefund->setStatusCode(100);
                $updateRefund->save();
            }
        }
    }
    public function getConfigData($value){
        return $this->scopeConfig->getValue(
            'payment/payu/'.$value,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

    }
}
