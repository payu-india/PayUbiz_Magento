<?php

namespace PayUIndia\Payu\Cron;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Sales\Model\RefundOrder;
use Magento\Sales\Model\Order\Creditmemo\ItemCreationFactory;

class RefundStatusCron
{
    protected $scopeConfig;
    protected $logger;
    protected $payuRefundFactory;
    protected $payuRefundHelper;
    protected $encrypted;
    protected $itemCreationFactory;

    protected $orderRepository;
  
    protected $refundOrder;
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        \PayUIndia\Payu\Model\PayuRefundFactory $payuRefundFactory,
        \PayUIndia\Payu\Helper\PayuRefund $payuRefundHelper,
        ItemCreationFactory $itemCreationFactory,
    OrderRepositoryInterface $orderRepository,
    RefundOrder $refundOrder,
        \Magento\Config\Model\Config\Backend\Encrypted $encrypted
        )
    {
        $this->scopeConfig = $scopeConfig;
        $this->payuRefundFactory = $payuRefundFactory;
        $this->payuRefundHelper = $payuRefundHelper;
        $this->encrypted = $encrypted;
        $this->itemCreationFactory = $itemCreationFactory;
        $this->orderRepository = $orderRepository;
        $this->refundOrder = $refundOrder;
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/payurefund.log');
		$this->logger = new \Zend_Log();
		$this->logger->addWriter($writer);
    }

    public function execute()
    {

        $refund = $this->payuRefundFactory->create();
        $refundData = $refund->getCollection()->addFieldToFilter('status_code',array('neq'=>100))->getData();
        $this->logger->info('Start Refund cron');
        
        foreach($refundData as $refund){
            $mihpayid=explode('-',$refund['mihpayid']);

            $url = 'https://info.payu.in/merchant/postservice.php?form=2';
            if( $this->getConfigData('environment') == 'sandbox' )
                $url = "https://test.payu.in/merchant/postservice.php?form=2";
            $this->encrypted->processValue($this->getConfigData("merchant_key"));
            $fields = array(
                'key' => $this->encrypted->processValue($this->getConfigData("merchant_key")),
                'command' => 'check_action_status',
                'var1' => $refund['refund_txn_id'],

            );
            $res=json_decode($refund['refund_txn_id']);

            $hash = hash("sha512", $fields['key'].'|'.$fields['command'].'|'.$fields['var1'].'|'.$this->encrypted->processValue($this->getConfigData('salt')));
            $fields['hash'] = $hash;

            $fields_string = http_build_query($fields);
            // Curl Execution
            $response=$this->payuRefundHelper->curlExecute($url,$fields_string);

            $res=json_decode($response);
            $this->logger->info('refund response from payu');
          
            $this->logger->info($response);
            $refundTxnId=$refund['refund_txn_id'];
            if($res->transaction_details->$refundTxnId->$refundTxnId->status=='success'){

                $updateRefund = $this->payuRefundFactory->create()->load($refund['id']);
                $updateRefund->setStatus('success');
                $updateRefund->setResponse(json_encode($res));
                $updateRefund->setRefundedAmount($res->transaction_details->$refundTxnId->$refundTxnId->amt);
                $updateRefund->setStatusCode(100);

                $updateRefund->save();
                $this->createCreditMemo($updateRefund->getOrderId());
            }
        }
    }
    public function getConfigData($value){
        return $this->scopeConfig->getValue(
            'payment/payu/'.$value,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

    }
    public function createCreditMemo(int $orderId)
    {
        $order = $this->orderRepository->get($orderId);
        if (!$order->canCreditmemo()) {
            $this->logger->info('Creditmemo could not be created ');
            $this->logger->info($orderId);
            return true;
        }
        $itemIdsToRefund = [];
        foreach ($order->getAllItems() as $orderItem) {
            $creditMemoItem = $this->itemCreationFactory->create();
        
            $creditMemoItem->setQty($orderItem->getQtyOrdered())->setOrderItemId($orderItem->getId());
            $itemIdsToRefund[] = $creditMemoItem;
        }
        $this->refundOrder->execute($orderId, $itemIdsToRefund);
        
    }    
}
