<?php
namespace PayUIndia\Payu\Cron;

class Webhook
{
    protected $logger;
    protected $webhookCollection;
    protected $webhookModel;
    protected $orderModel;
    protected $payuHelper;
    protected $paymentMethodModel;
    protected $payuRefundFactory;

    public function __construct(
        \PayUIndia\Payu\Model\ResourceModel\PayuWebhook\Collection $webhookCollection,
        \PayUIndia\Payu\Model\PayuWebhook $webhookModel,
        \Magento\Sales\Model\Order $orderModel,
        \PayUIndia\Payu\Helper\Payu $payuHelper,
        \PayUIndia\Payu\Model\Payu $paymentMethodModel,
        \PayUIndia\Payu\Model\PayuRefundFactory $payuRefundFactory,
    )
    {
        $this->webhookCollection = $webhookCollection;
        $this->webhookModel = $webhookModel;
        $this->orderModel = $orderModel;
        $this->paymentMethodModel = $paymentMethodModel;
        $this->payuHelper = $payuHelper;
        $this->payuRefundFactory = $payuRefundFactory;
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/webhookcron.log');
        $this->logger = new \Zend_Log();
        $this->logger->addWriter($writer);
    }

    public function execute()
    {
        $webhookCollectionData=$this->webhookCollection->addFieldToFilter('status',0);
        foreach($webhookCollectionData as $data){
            $modelData=$this->webhookModel->load($data->getId());
            $this->logger->info('Webhook cron : ');
            $webhookDataArr=json_decode($data->getResponse(),true);
            $order=$this->orderModel->load($data->getTxnId(),'txnid');
            $this->logger->info(json_encode($order->getData(),true));
            $quoteid=explode('-',$webhookDataArr['txnid']);
            $billingAddress=$order->getBillingAddress();
            $txnid=$webhookDataArr['txnid'];
            $amount=$webhookDataArr['amount'];
            $productInfo=$quoteid[0];
            $name=$billingAddress->getFirstname();
            $email=$billingAddress->getEmail();
            $udf1=$webhookDataArr['udf1'];
            $udf5=$webhookDataArr['udf5'];
            $hash=$this->paymentMethodModel->generatePayuHash($txnid, $amount, $productInfo, $name,
                $email,$udf1,$udf5);
            $this->logger->info($hash);
            $this->logger->info($webhookDataArr['hash']);
            if ($order->getState() == 'pending_payment' && $data->getPaymentResponse() == 'success' && $data->getType()=='payment') {
                $this->payuHelper->updateOrderFromResponse($order, $webhookDataArr);
                $payment = $order->getPayment();
                $this->paymentMethodModel->postProcessing($order, $payment, $webhookDataArr);
                $modelData->setStatus(1);
                $modelData->save();
            } elseif ($order->getState() == 'pending_payment' && $data->getPaymentResponse() == 'failure' && $data->getType()=='payment') {
                $order->setStatus('canceled');
                $order->setState('canceled');
                $order->save();
                $modelData->setStatus(1);
                $modelData->save();
            } elseif ($order->getState() == 'processing' && $data->getType()=='refund' && $data->getPaymentResponse() == 'success'){
                $refundModel = $this->payuRefundFactory->create()->load($data->getRequestId(),'refund_txn_id');
                $refundModel->setStatusCode(100);
                $refundModel->setStatus($data->getPaymentResponse());
                $refundModel->setResponse($data);
                $modelData->setStatus(1);
                $modelData->save();
            }
            else {
                $modelData->setStatus(1);
                $modelData->save();
            }
        }
        $this->logger->info("webhook and order has been updated");

    }
}
