<?php

namespace PayUIndia\Payu\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class UpdatePayuAddress implements ObserverInterface
{
    protected $payuaddress;
    protected $customerModelFactory;
    public function __construct(
        \PayUIndia\Payu\Model\PayuAddress $payuAddress,
        \Magento\Customer\Model\CustomerFactory $customerModelFactory
    )
    {
        $this->payuaddress = $payuAddress;
        $this->customerModelFactory = $customerModelFactory;
    }

    public function execute(Observer $observer)
    {
        $customerAddress = $observer->getCustomerAddress();
//        print_r($customerAddress->getdata());exit;
        $customerData=$this->customerModelFactory->create()->load($customerAddress->getCustomerId());

        if(!empty($customerAddress->getCustomAttributes('payu_user_id')))
            $this->payuaddress->updateAddress($customerAddress);
        else{
            $this->payuaddress->saveAddress($customerAddress,$customerData);
        }
//            print_r($customerAddress->getdata());exit;
    }
}
