<?php

namespace PayUIndia\Payu\Observer;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class PayuCustomerPhoneNumber implements ObserverInterface
{
    protected $customerModelFactory;
    protected $payuAddress;
    public function __construct(
        \Magento\Customer\Model\CustomerFactory $customerModelFactory,
        \PayUIndia\Payu\Model\PayuAddress $payuAddress
    )
    {
        $this->customerModelFactory=$customerModelFactory;
        $this->payuAddress = $payuAddress;
    }

    public function execute(Observer $observer)
    {
        $data=$observer->getEvent()->getCustomer();
        $customerData=$this->customerModelFactory->create()->load($data->getEntityId());
        $customerPhoneNumber=$customerData->getPayuPhoneNumber();
        $email= $data->getEmail();
        $addresses = $data->getAddresses();
        foreach ($addresses as $address){
            if(empty($address->getPayuUserId()))
                $this->payuAddress->saveAddress($address,$customerData);
        }

    }
}
