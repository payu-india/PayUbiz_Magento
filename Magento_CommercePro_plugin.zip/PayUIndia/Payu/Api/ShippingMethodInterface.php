<?php
namespace PayUIndia\Payu\Api;
use Magento\Quote\Api\Data\AddressInterface;

interface ShippingMethodInterface
{

/**
 * 
 * 
 * @return Array
 * 
 */

    public function getShippingMethods();
}

// AddressInterface $address, string $quote_id
// @param AddressInterface $address
//  * @param string $quote_id