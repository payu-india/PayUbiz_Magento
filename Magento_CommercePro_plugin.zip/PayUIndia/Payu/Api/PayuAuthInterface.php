<?php
namespace PayUIndia\Payu\Api;

interface PayuAuthInterface
{

/**
 * 
 * @param string $email
 * @return Array
 * 
 */

    public function getToken($email);
}

// AddressInterface $address, string $quote_id
// @param AddressInterface $address
//  * @param string $quote_id