<?php

namespace PayUIndia\Payu\Controller\Standard;

class Cancel extends \PayUIndia\Payu\Controller\PayuAbstract {

    public function execute() {

	$paymentMethod = $this->getPaymentMethod();
        $allParam = $this->getRequest()->getParams();
        $header = $this->getRequest()->getHeaders();
        if(array_key_exists('full_response',$allParam)){
            $params = json_decode($allParam['full_response'],true);
        }else{
            $params = $allParam;
        }
        $this->getCheckoutHelper()->saveEventLogs("",$header,"",$params);
        $quoteId = $params["txnid"];
        if(strpos($quoteId,'-') > 0)
        {
            $q=explode('-',$quoteId);
            $quoteId=$q[0];
        }

        $quote = $this->quoteRepository->get($quoteId);
        $order = $this->getOrderById($quote->getReservedOrderId());
        $this->getCheckoutHelper()->setAddress($order,$params);
        $this->getCheckoutHelper()->assignCustomer($params);
		$paymentMethod->cancelOrder($order);
        if($params['udf5'] && !$this->getCustomerSession()->isLoggedIn() && ($quote->getCustomerId())) {
            $this->checkoutSession->setSessionId($params['udf5']);
            $this->getCustomerSession()->setSessionId($params['udf5']);
        }
        $goto=$this->_cancelPayment('Payment canceld/failed...Order canceled...');
        $this->messageManager->addErrorMessage(__('Your order has been canceled'));
        $this->getResponse()->setRedirect(
                $this->getCheckoutHelper()->getUrl('checkout').'/'.$goto
        );
    }

}
