<?php

namespace PayUIndia\Payu\Controller\Standard;

class Cancel extends \PayUIndia\Payu\Controller\PayuAbstract {

    public function execute() {

	$paymentMethod = $this->getPaymentMethod();
        $allParam = $this->getRequest()->getParams();
        $header = $this->getRequest()->getHeaders();
        if(array_key_exists('full_response',$allParam)){
            $params = json_decode($allParam['full_response'],true);
            $request = json_decode($allParam['full_request'],true);
        }else{
            $params = $allParam;
        } 
       
       $order=$this->getOrder();
      
        $params = [
            "txnid" => $params["txnId"] ?? $params["txnid"] ?? $order->getTxnid(), // Handle null value for txnId
            "status" => $params["txnStatus"] ??  $params["status"],
            "txnmessage" => $params["txnMessage"] ??$params["error_Message"],
        ];
       // dd($params);
        $this->getCheckoutHelper()->saveEventLogs("",$header,"",$params);
        $quoteId = $params["txnid"];
        if(strpos($quoteId,'-') > 0)
        {
            $q=explode('-',$quoteId);
            $quoteId=$q[0];
        }
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/payu.log'); 
        $logger = new \Zend_Log(); 
        $logger->addWriter($writer); 
        $logger->info('Custom message');
        $logger->info('order id ' . json_encode($order->getIncrementId()));
        $logger->info('response '.json_encode($params));
        $quote = $this->quoteRepository->get($quoteId);
        $order = $this->getOrderById($quote->getReservedOrderId());
        if (isset($params['shipping_address']['addressLine'])) {
            $streetData = $params['shipping_address']['addressLine'];
        } else {
            $streetData = (isset($params['address1']) ? $params['address1'] : '') . 
                          (isset($params['address2']) ? ' ' . $params['address2'] : '');
        }
        if (!empty($streetData)) {
            $this->getCheckoutHelper()->setAddress($order, $params);
        }
        if (isset($params['email']) && !empty($params['email'])) {
            $email = $params['email'];
        } else {
            $email = isset($params['shipping_address']['email']) ? $params['shipping_address']['email'] : null;
        }
        if (!empty($email)) {
            $this->getCheckoutHelper()->assignCustomer($params);
        }
		//$paymentMethod->cancelOrder($order);
        if(isset($params['udf5']) && !$this->getCustomerSession()->isLoggedIn() && ($quote->getCustomerId())) {
            $this->checkoutSession->setSessionId($params['udf5']);
            $this->getCustomerSession()->setSessionId($params['udf5']);
        }
        $goto=$this->_cancelPayment('Payment canceld/failed...Order canceled...');
        //$this->messageManager->addErrorMessage(__('Your order has been canceled'));
        $this->getResponse()->setRedirect(
                $this->getCheckoutHelper()->getUrl('checkout').'/'.$goto
        );
    }

}
