<?php

namespace PayUIndia\Payu\Controller\Standard;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Response extends \PayUIndia\Payu\Controller\PayuAbstract  implements CsrfAwareActionInterface, HttpPostActionInterface, HttpGetActionInterface {

    public function execute() {
        $returnUrl = $this->getCheckoutHelper()->getUrl('checkout');

        try {
            $paymentMethod = $this->getPaymentMethod();
            $allParam = $this->getRequest()->getParams();
            //	print_r($allParam);die;
            $header = $this->getRequest()->getHeaders();
            if(array_key_exists('full_response',$allParam)){
                $params = json_decode($allParam['full_response'],true);
            }else{
                $params = $allParam;
            }
		    $this->getCheckoutHelper()->saveEventLogs("",$header,"",$params);
            $customerModel = $this->customerModelFactory->create()->getCollection()->addAttributeToFilter('email',['eq' => $params['email']]);
            // print_r($customerModel->getSelect()->__toString());
            // echo "<pre>";print_r($customerModel->getData());
            // echo "<pre>";print_r($params);die(__FILE__);
            
            //save order response
            $this->getCheckoutHelper()->saveEventLogs("",$header,"",$params);
            if ($paymentMethod->validateResponse($params)) {

                $returnUrl = $this->getCheckoutHelper()->getUrl('checkout/onepage/success');

                $quoteId = $params["txnid"];
                if(strpos($quoteId,'-') > 0)
                {
                    $q=explode('-',$quoteId);
                    $quoteId=$q[0];
                }

                $quote = $this->quoteRepository->get($quoteId);

                if($params['udf5'] && !$this->getCustomerSession()->isLoggedIn() && ($quote->getCustomerId())) {
                    //                $this->checkoutSession->setSessionId($params['udf1']);
                    $this->getCustomerSession()->setSessionId($params['udf5']);
                }

                if($paymentMethod->getConfigData('debuglog')==true)
                    $this->_logger->debug("PayU Response QuoteID: ".$quoteId);

                $quote->getPayment()->setMethod($paymentMethod->getMethodCode());

                if($paymentMethod->getConfigData('debuglog')==true)
                    $this->_logger->debug("PayU Creating Order ...");

                // set customer email if email found empty (Bug)
                if ($quote->getCustomerEmail() === null && $quote->getBillingAddress()->getEmail() !== null )
                {
                    $quote->setCustomerEmail($quote->getBillingAddress()->getEmail());
                    $this->_logger->debug("PayU Guest Checkout - magento email bug fix applied ...");
                }

                $this->_logger->debug("PayU submitting quote to order ...");
                $quote->save();
                // $order = $this->quoteManagement->submit($quote);
                $order = $this->getOrderById($quote->getReservedOrderId());
                // update order data
                $this->getCheckoutHelper()->updateOrderFromResponse($order,$params);

                // echo "<pre>"; print_r($order->debug()); die;
                if($paymentMethod->getConfigData('debuglog')==true)
                    $this->_logger->debug("PayU Created Order ...");

                $this->checkoutSession->setLastSuccessQuoteId($quote->getId())
                    ->setLastQuoteId($quote->getId())
                    ->clearHelperData();
                if(empty($order) === false)
                {
                    if($paymentMethod->getConfigData('debuglog')==true)
                        $this->_logger->debug("PayU Updating Order ...");

                    $payment = $order->getPayment();
                    $method = $payment->getMethodInstance();

                    if($paymentMethod->getConfigData('debuglog')==true)
                        $this->_logger->debug("Order Payment Method: ".strtolower($method->getTitle()));

                    $paymentMethod->postProcessing($order, $payment, $params);

                    // Fix for Bug- Order Item 'base_original_price' and 'original_price' not updated during order save
                    foreach ($order->getAllItems() as $item)
                    {
                        $item->setOriginalPrice($item->getPrice())->setBaseOriginalPrice($item->getPrice())->save();
                    }

                    $quote->setIsActive(false)->save();
                    $this->checkoutSession->replaceQuote($quote);
                    $this->checkoutSession->setLastOrderId($order->getId())
                        ->setLastRealOrderId($order->getIncrementId())
                        ->setLastOrderStatus($order->getStatus());

                    if($paymentMethod->getConfigData('debuglog')==true)
                        $this->_logger->debug("PayU Updated Order ...Redirecting to Success...");
                    $order->setIsNotified(true);
                    $order->setBaseTotalPaid($order->getBaseGrandTotal());
                    $order->setTotalPaid($order->getGrandTotal());
                    $order->save();
                    // echo "<pre>"; print_r($order->debug()); die;
                }

            } else {
                //$this->getOrder()->cancel()->save(); //modified

                $quoteId = $params["txnid"];
                if(strpos($quoteId,'-') > 0)
                {
                    $q=explode('-',$quoteId);
                    $quoteId=$q[0];
                }

                $quote = $this->quoteRepository->get($quoteId);
                $order = $this->getOrderById($quote->getReservedOrderId());
                $this->getCheckoutHelper()->setAddress($order,$params);
               // $this->getCheckoutHelper()->assignCustomer($params);
                $paymentMethod->cancelOrder($order);
                $this->messageManager->addErrorMessage(__('Payment failed.'));
                $returnUrl = $this->getCheckoutHelper()->getUrl('checkout/onepage/failure');
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addExceptionMessage($e, $e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('We can\'t place the order.'));
        }
        $this->getResponse()->setRedirect($returnUrl);
    }

    /**
     * @inheritDoc
     */
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    /**
     * @inheritDoc
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}
