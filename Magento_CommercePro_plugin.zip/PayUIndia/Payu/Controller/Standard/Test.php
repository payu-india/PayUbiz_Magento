<?php

namespace PayUIndia\Payu\Controller\Standard;

use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;

class Test extends \PayUIndia\Payu\Controller\PayuAbstract  implements CsrfAwareActionInterface, HttpPostActionInterface, HttpGetActionInterface {

    public function execute() {
		
		$paymentMethod = $this->getPaymentMethod();
			
		$env = $paymentMethod->getConfigData('environment');
		$ordDetailAPiUrl = 'https://apitest.payu.in/cart/order/';
        if ($env === 'production') {
            $ordDetailAPiUrl = 'https://api.payu.in/cart/order/';
        }
        $txnID = '235-8ac84e4f';
        $ordDetailAPiUrl = $ordDetailAPiUrl.$txnID;
        
        $udf1 = 'Magento2.4.6';
        $requestJson = json_encode( array('udf1'=>$udf1) );
        
        
        
    }
    
        /**
     * @inheritDoc
     */
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

    /**
     * @inheritDoc
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }



}
