<?php

namespace PayUIndia\Payu\Controller\Standard;

class Redirect extends \PayUIndia\Payu\Controller\PayuAbstract {

    public function execute() {
        if (!$this->getRequest()->isAjax()) {
            $this->_cancelPayment();
            $this->checkoutSession->restoreQuote();
            $this->getResponse()->setRedirect(
                    $this->getCheckoutHelper()->getUrl('checkout')
            );
        }
        $quote = $this->getQuote();
        $email = $this->getRequest()->getParam('email');
       
        if (!$this->getCustomerSession()->isLoggedIn()) {
            $quote->setCheckoutMethod(\Magento\Checkout\Model\Type\Onepage::METHOD_GUEST);
            $quote->setCustomerIsGuest(true);
            $quote->setCustomerEmail($email);
            $quote->getBillingAddress()->setEmail($email);
            $quote->save();
        }
        $html = $this->getPaymentMethod()->buildCheckoutRequest();
        //dd($html);
		if(isset($html['error'])) {
			$this->_logger->error("PayU Error-".json_encode($html)); 	
		    return $this->resultJsonFactory->create()->setData(['error' => $html['error']]);

		}
	
		return $this->resultJsonFactory->create()->setData(['html' => $html['data']]);
    }

}
