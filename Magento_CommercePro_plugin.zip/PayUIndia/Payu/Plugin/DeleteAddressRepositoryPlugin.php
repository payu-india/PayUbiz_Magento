<?php
namespace PayUIndia\Payu\Plugin;

use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;

class DeleteAddressRepositoryPlugin
{
    protected $payuaddress;
    protected $customerModelFactory;
    public function __construct(
        \PayUIndia\Payu\Model\PayuAddress $payuAddress,
        \Magento\Customer\Model\CustomerFactory $customerModelFactory
    )
    {
        $this->payuaddress = $payuAddress;
        $this->customerModelFactory = $customerModelFactory;
    }
    public function beforeDeleteById(AddressRepositoryInterface $subject, $addressId)
    {
        $customerAddress=$subject->getById($addressId);
        $this->payuaddress->deleteAddress($customerAddress);
        return [$addressId];
    }
}
