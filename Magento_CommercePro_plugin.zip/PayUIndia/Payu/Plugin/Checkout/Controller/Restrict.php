<?php
 
namespace PayUIndia\Payu\Plugin\Checkout\Controller;
 
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\UrlFactory;
use Magento\Checkout\Controller\Index\Index;
 
class Restrict
{
    private $urlModel;
    private $resultRedirectFactory;
    private $messageManager;
    protected $cartBlock;
 
    public function __construct(
        UrlFactory $urlFactory,
        RedirectFactory $redirectFactory,
        ManagerInterface $messageManager,
        \PayUIndia\Payu\Block\Cart $cartBlock

    ) {
    
        $this->urlModel = $urlFactory;
        $this->resultRedirectFactory = $redirectFactory;
        $this->messageManager = $messageManager;
        $this->cartBlock = $cartBlock;
    }
 
    public function aroundExecute(
        Index $subject,
        \Closure $proceed
    ) {
    
        $this->urlModel = $this->urlModel->create();
        
        if($this->cartBlock->isExpressCheckout()){

            $defaultUrl = $this->urlModel->getUrl('checkout/cart/', ['_secure' => true]);
            $resultRedirect = $this->resultRedirectFactory->create();
            return $resultRedirect->setUrl($defaultUrl);
        }
 
        return $proceed();
    }
}