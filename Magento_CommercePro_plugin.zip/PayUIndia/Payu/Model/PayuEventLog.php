<?php

namespace PayUIndia\Payu\Model;

use Magento\Framework\Model\AbstractModel;
use PayUIndia\Payu\Model\ResourceModel\PayuEventLog as ResourceModel;

class PayuEventLog extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}
