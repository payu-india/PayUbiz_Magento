<?php

namespace PayUIndia\Payu\Model;

use PayUIndia\Payu\Api\PayuAuthInterface;
use Magento\Framework\Exception\LocalizedException;


class AuthPayu implements PayuAuthInterface
{

    protected $payuAuthFactory;
    protected $jsonEncoder;
    protected $date;

    public function __construct(
	\Magento\Framework\Json\EncoderInterface $jsonEncoder,
    PayuAuthFactory $payuAuthFactory,
    \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date

    ) {

        $this->payuAuthFactory = $payuAuthFactory;
        $this->jsonEncoder = $jsonEncoder;
        $this->date = $date;
    }
    public function getToken($email)
    {
        if (trim($email) !== '' && str_contains($email,'@') && str_contains($email,'.')) {
            // $authToken=md5($email.microtime());
            $authToken=hash('sha256',$email.microtime());
            $expirationTime = $this->date->date()->add(new \DateInterval('PT24H'))->format('Y-m-d H:i:s');
            $data=['email'=>$email,
                    'token'=>$authToken,
                    'expired_at'=>$expirationTime];
            $authModel=$this->payuAuthFactory->create();
            $collection=$authModel->getCollection()->addFieldToFilter('email',$email);
            if(count($collection->getData())<1){
                $authModel->setData($data);
                $authModel->save();
            }else{
                $id=$collection->getFirstItem()->getId();
                $currentDateTime = $this->date->date()->format('Y-m-d H:i:s');
                if($currentDateTime>$collection->getFirstItem()->getExpiredAt()){
                    $authModel->load($id)
                        ->setEmail($email)
                        ->setToken($authToken)
                        ->setExpiredAt($expirationTime);
                    $authModel->save();
                }else{
                    $authToken=$collection->getFirstItem()->getToken();
                }

            }
            $status = true;
            $message = "Token Generated";
            $token['token']=$authToken;
            echo $this->getResponseJson($token,$status,$message);
            die;
        }else{
            $status = false;
            $message = "Enter the valid email and try again.";
            $authToken=[];
            echo $this->getResponseJson($authToken,$status,$message);
            die;
        }
    }
    public function getResponseJson($result,$status="",$message="")
	{
		$data["status"]=$status;
		$data["message"]=$message;
		$data["data"]= $result;
        return $this->jsonEncoder->encode($data);
	}
}
