<?php
namespace PayUIndia\Payu\Model\ResourceModel\PayuRefund;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use PayUIndia\Payu\Model\PayuRefund as Model;
use PayUIndia\Payu\Model\ResourceModel\PayuRefund as ResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}