<?php
namespace PayUIndia\Payu\Model\ResourceModel\PayuAuth;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use PayUIndia\Payu\Model\PayuAuth as Model;
use PayUIndia\Payu\Model\ResourceModel\PayuAuth as ResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}