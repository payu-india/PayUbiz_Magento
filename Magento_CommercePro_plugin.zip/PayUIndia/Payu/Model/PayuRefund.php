<?php

namespace PayUIndia\Payu\Model;

use Magento\Framework\Model\AbstractModel;
use PayUIndia\Payu\Model\ResourceModel\PayuRefund as ResourceModel;

class PayuRefund extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}