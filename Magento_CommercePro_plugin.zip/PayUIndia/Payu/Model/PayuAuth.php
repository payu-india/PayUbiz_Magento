<?php

namespace PayUIndia\Payu\Model;

use Magento\Framework\Model\AbstractModel;
use PayUIndia\Payu\Model\ResourceModel\PayuAuth as ResourceModel;

class PayuAuth extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(ResourceModel::class);
    }
}