<?php

namespace PayUIndia\Payu\Model;

use Magento\Customer\Model\Data\Address;

class ExtendedAddress extends Address
{
    /**
     * Get Payu User Id
     *
     * @return int|null
     */
    public function getPayuUserId()
    {
        return $this->_get('payu_user_id');
    }

    /**
     * Set Payu User Id
     *
     * @param int $payuUserId
     * @return $this
     */
    public function setPayuUserId($payuUserId)
    {
        return $this->setData('payu_user_id', $payuUserId);
    }

    /**
     * Get Payu Address Id
     *
     * @return int|null
     */
    public function getPayuAddressId()
    {
        return $this->_get('payu_address_id');
    }

    /**
     * Set Payu Address Id
     *
     * @param int $payuAddressId
     * @return $this
     */
    public function setPayuAddressId($payuAddressId)
    {
        return $this->setData('payu_address_id', $payuAddressId);
    }
}
