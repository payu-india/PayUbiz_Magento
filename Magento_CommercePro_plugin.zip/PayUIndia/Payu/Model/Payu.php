<?php
namespace PayUIndia\Payu\Model;

use Magento\Sales\Api\Data\TransactionInterface;
use Magento\Sales\Model\Order;
use Magento\Payment\Model\InfoInterface;
use Magento\Framework\Exception\LocalizedException;


class Payu extends \Magento\Payment\Model\Method\AbstractMethod {

    const PAYMENT_PAYU_CODE = 'payu';
    const ACC_BIZ = 'payubiz';
    const ACC_MONEY = 'payumoney';

    protected $_code = self::PAYMENT_PAYU_CODE;

	protected $_canRefund = true;
    protected $_canRefundInvoicePartial = true;

    protected $_isInitializeNeeded      = true;
    protected $_isOffline               = false;
    protected $_isGateway = true;

    protected $_canAuthorize = true;
    protected $_canCapture = true;


    /**
     *
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlBuilder;
    protected $_supportedCurrencyCodes = array(
        'AFN', 'ALL', 'DZD', 'ARS', 'AUD', 'AZN', 'BSD', 'BDT', 'BBD',
        'BZD', 'BMD', 'BOB', 'BWP', 'BRL', 'GBP', 'BND', 'BGN', 'CAD',
        'CLP', 'CNY', 'COP', 'CRC', 'HRK', 'CZK', 'DKK', 'DOP', 'XCD',
        'EGP', 'EUR', 'FJD', 'GTQ', 'HKD', 'HNL', 'HUF', 'INR', 'IDR',
        'ILS', 'JMD', 'JPY', 'KZT', 'KES', 'LAK', 'MMK', 'LBP', 'LRD',
        'MOP', 'MYR', 'MVR', 'MRO', 'MUR', 'MXN', 'MAD', 'NPR', 'TWD',
        'NZD', 'NIO', 'NOK', 'PKR', 'PGK', 'PEN', 'PHP', 'PLN', 'QAR',
        'RON', 'RUB', 'WST', 'SAR', 'SCR', 'SGF', 'SBD', 'ZAR', 'KRW',
        'LKR', 'SEK', 'CHF', 'SYP', 'THB', 'TOP', 'TTD', 'TRY', 'UAH',
        'AED', 'USD', 'VUV', 'VND', 'XOF', 'YER'
    );

	protected $_logger;

    private $checkoutSession;

	private $customerSession;
	protected $refundHelper;
    protected $storeManager;
    protected $payuAddress;
    protected $encrypted;
    protected $scopeConfig;
    protected static $certificate_path = __DIR__ . '/../certificates/cacert.pem';


    /**
     *
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $logger
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb $resourceCollection
     * @param array $data
     */
      public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \PayUIndia\Payu\Helper\Payu $helper,
        \PayUIndia\Payu\Helper\PayuRefund $refundHelper,
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
        \Magento\Framework\HTTP\ZendClientFactory $httpClientFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
        \PayUIndia\Payu\Model\PayuAddress $payuAddress,
        \Magento\Config\Model\Config\Backend\Encrypted $encrypted,
        ?\Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        ?\Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []

    ) {
        $this->helper = $helper;
        $this->refundHelper = $refundHelper;
        $this->orderSender = $orderSender;
        $this->httpClientFactory = $httpClientFactory;
        $this->checkoutSession = $checkoutSession;
		$this->customerSession = $customerSession;
		$this->_logger = $logger;
		$this->storeManager = $storeManager;
        $this->payuAddress=$payuAddress;
        $this->encrypted=$encrypted;
        $this->scopeConfig = $scopeConfig;

        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data
        );

    }

    public function canUseForCurrency($currencyCode) {
        if (!in_array($currencyCode, $this->_supportedCurrencyCodes)) {
            return false;
        }
        return true;
    }

	public function getMethodCode()
	{
		return $this->_code;
	}

    public function getRedirectUrl() {
        return $this->helper->getUrl($this->getConfigData('redirect_url'));
    }

    public function getReturnUrl() {
        return $this->helper->getUrl($this->getConfigData('return_url'));
    }

    public function getCancelUrl() {
        return $this->helper->getUrl($this->getConfigData('cancel_url'));
    }

	public function getMethodTitle() {
		return $this->getConfigData("title");
	}
	public function getFetchDynamicCharges() {
		return $this->getConfigData("fetch_dynamic_charges");
	}
    /**
     * Return url according to environment
     * @return string
     */
    public function getCgiUrl() {
        $env = $this->getConfigData('environment');
        if ($env === 'production') {
            return $this->getConfigData('production_url');
        }
        return $this->getConfigData('sandbox_url');
    }

	public function initialize($paymentAction, $stateObject) {
        $payment = $this->getInfoInstance();
        $order = $payment->getOrder();
        $order->setCanSendNewEmailFlag(false);
        $stateObject->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT);
        $stateObject->setIsNotified(false);
    }

    public function buildCheckoutRequest() {

		$quote = $this->checkoutSession->getQuote();
	
		//$this->_logger->debug(json_encode($quote->getData()));

		// echo "<pre>";
		//print_r($quote);die;
		if (!$quote->hasItems())
        {
			return ['error' => 'Empty cart...'];

		}
        $txnid = $quote->getId().'-'.bin2hex(random_bytes(4));
        $this->helper->createTempOrder($txnid);
		$billing_address = $quote->getBillingAddress();

        $mkey=$this->encrypted->processValue($this->getConfigData("merchant_key"));
		$sprovider = "";

		if ($this->getConfigData('account_type') == self::ACC_MONEY) {
			$sprovider=$this->getConfigData("service_provider");
		}



		$amount = round($quote->getGrandTotal(), 2);
		$udf1 	= 'Magento2';
		$udf5 	= $this->checkoutSession->getSessionId();
		$email  = $quote->getCustomerEmail();

		if(empty($email))
		{
			$email = $billing_address->getEmail() ?? '';
		}

		$params = array();
		$params['action'] = $this->getConfigData('paymentaction'); //redirect or express checkout

		$phone = $billing_address->getTelephone() ?? '9898989898';
		$phone  = str_replace('+91','',$phone);

		if($params['action']=='expresscheckout')
		{
			$SALT = $this->encrypted->processValue($this->getConfigData('salt'));
            $amount = round($quote->getBaseSubtotal(), 2);
			$cartArr = [];
			$cartArr['amount'] = (string)round($quote->getBaseSubtotal(), 2);
			$cartArr['items']  = (string)(int)$quote->getItemsQty();
			$cartArr['sku_details']  = [];

			$items = $quote->getItems();
			foreach ($items as $item){
				$itemArr = [];
				$itemArr['offer_key'] = [];
				$itemArr['amount_per_sku'] = (string) round($item->getPrice(),2);
				$itemArr['quantity']       = (string)(int)$item->getQty();
				$itemArr['sku_id']   =  $item->getSku();
				$itemArr['sku_name'] =  $item->getName();
				$itemArr['logo'] = '';
				$cartArr['sku_details'][] = $itemArr;
			}

			$fname = $billing_address->getFirstName() ?? 'Guest';
			$lname = $billing_address->getLastname() ?? 'User';

			$expHashData = $this->generatePayuExpressHash($txnid, $amount, $cartArr, $fname,$lname,$phone,$email,$udf1,$udf5);

		    // use $expHashData['expressData'] variable to save data in event log
            $this->helper->saveEventLogs('EXPRESS - Payment',$header=null,$expHashData['expressData']);

			$params['data'] = "
			<form action='' method='post' style='display: none' id='frm_payu_response' name='frm_payu_response' enctype='multipart/form-data'>
				<input type='hidden' id='full_response' name='full_response' value='' >
				<input type='hidden' id='full_request' name='full_request' value='' >
				<input type='submit' id='sbt' name='sbt' value='Submit' >
			</form>
			<script type='text/javascript'>
					require(['jquery', 'mage/loader'], function($) {
					
			function expressCheckoutSubmit() {
			$('body').loader('show');
				const  expressRequestObj = {
					data: '".$expHashData['data']."',
					date: '".$expHashData['date']."',
					isCheckoutExpress: true,
					v2Hash: '".$expHashData['v2Hash']."'
				}

				var handlers = {
					responseHandler: function (BOLT) {
							console.log('Payment details...'+JSON.stringify(BOLT.response));
							var frm = document.getElementById('frm_payu_response');
							if(BOLT.response.surl !== undefined){
								frm.action = BOLT.response.surl;
							}else {
								frm.action = '".$this->getCancelUrl()."';
							}
							frm.elements.namedItem('full_response').value = JSON.stringify(BOLT.response);
							frm.submit();
						},
					catchException: function (BOLT) {
							console.log('Payment failed. Please try again.');
				}};
				bolt.launch( expressRequestObj , handlers);
			}

			expressCheckoutSubmit();
			});
			</script>";

		} elseif($params['action']=='bolt')  {
			$hash = $this->generatePayuHash($txnid,$amount,$quote->getId(), $billing_address->getFirstName(), $email,$udf1,$udf5);
			$requestArr = [
				'key' => $mkey,
				'Hash' => $hash,
			    'txnid' => $txnid,
			    'amount' => $amount,
			    'firstname' => $billing_address->getFirstName(),
			    'Lastname' => $billing_address->getLastname(),
			    'email' => $email,
				'phone' => $phone,
				'productinfo' => $quote->getId(),
				'surl' => $this->getReturnUrl(),
				'furl' => $this->getCancelUrl(),
				'udf1' => $udf1,
				'udf5' => $udf5,
                'sku_details' => []
			];
            foreach ($quote->getItems() as $item){
                $itemArr = [];
                $itemArr['offer_key'] = [];
                if($item->getDiscountAmount()) {
                    $amountPerSku = ($item->getBasePrice() * $item->getQty()) - $item->getBaseDiscountAmount();
                }
                $itemArr['amount_per_sku'] = isset($amountPerSku) ? (string) round($amountPerSku,2) : (string) round($item->getBasePrice(),2);
                $itemArr['quantity']       = (string)(int)$item->getQty();
                $itemArr['sku_id']   =  $item->getSku();
                $itemArr['sku_name'] =  $item->getName();
                $itemArr['logo'] = '';
                $requestArr['sku_details'][] = $itemArr;
            }

		   // use $requestArr variable to save data in event log
            $this->helper->saveEventLogs('BOLT - Payment',$header=null,$requestArr);

			$params['data'] = "<form action='' method='post' style='display: none' id='frm_payu_response' name='frm_payu_response' enctype='multipart/form-data'>
				<input type='hidden' id='full_response' name='full_response' value='' >
				<input type='hidden' id='full_request' name='full_request' value='' >
				<input type='submit' id='sbt' name='sbt' value='Submit' >
			</form>
			<script type='text/javascript'>
					require(['jquery', 'mage/loader'], function($) {
					function boltSubmit()
					{
					$('body').loader('show');
						var data = ".json_encode($requestArr).";
						var handlers = {
							responseHandler: function (BOLT) {
									console.log('Payment details...'+JSON.stringify(BOLT.response));
									var frm = document.getElementById('frm_payu_response');
									if(BOLT.response.surl !== undefined){
										frm.action = BOLT.response.surl;
									}else {
										frm.action = '".$this->getCancelUrl()."';
									}
									frm.elements.namedItem('full_response').value = JSON.stringify(BOLT.response);
									frm.submit();
								},
							catchException: function (BOLT) {
									console.log('Payment failed. Please try again.');
						}};
						bolt.launch( data , handlers );
						return false;
					}

					boltSubmit();
					});
					</script>";
		}

		elseif($params['action']=='redirect')
		{
			$hash = $this->generatePayuHash($txnid,$amount,$quote->getId(), $billing_address->getFirstName(), $email,$udf1,$udf5);
			$requestArr = [
				'key' => $mkey,
			    'txnid' => $txnid,
			    'amount' => $amount,
			    'productinfo' => $quote->getId(),
			    'firstname' => $billing_address->getFirstName(),
			    'Lastname' => $billing_address->getLastname(),
			    'city' => $billing_address->getCity(),
			    'state' => $billing_address->getRegion(),
			    'zip' => $billing_address->getPostcode(),
			    'country' => $billing_address->getCountryId(),
			    'email' => $email,
				'phone' => $phone,
				'udf1' => $udf1,
				'udf5' => $udf5,
				'surl' => $this->getReturnUrl(),
				'furl' => $this->getCancelUrl(),
				'curl' => $this->getCancelUrl(),
				'service_provider' => $sprovider,
				'Hash' => $hash,
				'Pg' => '',
			    'sku_details' => ""
			];

            foreach ($quote->getItems() as $item){
                $itemArr = [];
                $itemArr['offer_key'] = [];
                if($item->getDiscountAmount()) {
                    $amountPerSku = ($item->getBasePrice() * $item->getQty()) - $item->getBaseDiscountAmount();
                }
                $itemArr['amount_per_sku'] = isset($amountPerSku) ? (string) round($amountPerSku,2) : (string) round($item->getBasePrice(),2);
                            $itemArr['quantity']       = (string)(int)$item->getQty();
                $itemArr['sku_id']   =  $item->getSku();
                $itemArr['sku_name'] =  $item->getName();
                $itemArr['logo'] = '';
                //$requestArr['sku_details'][] = $itemArr;
            }
            // use $requestArr variable to save data in event log
            $this->helper->saveEventLogs('REDIRECT - Payment',$header=null,$requestArr);

			$red_input = '';
			foreach($requestArr as $r_key => $r_val){
				$red_input.='<input type="hidden" name="'.$r_key.'" value="'.$r_val.'" />';
			}

			$params['data'] = "<form action=\"".$this->getCgiUrl()."\" method=\"post\" id=\"payu_payment_form\" name=\"payu_payment_form\">
						$red_input
						<button style='display:none' id='submit_payu_payment_form' name='submit_payu_payment_form'>Pay Now</button>
					</form>
					<script type=\"text/javascript\">document.getElementById(\"payu_payment_form\").submit();</script>";
		}
        

        return $params;
    }

    public function generatePayuExpressHash($txnid, $amount, $cartDetail, $firstname,$lastname,$phone,$email,$udf1,$udf5){

			$c_date = gmdate('D, d M Y H:i:s T');
			$payu_salt = $this->encrypted->processValue($this->getConfigData("salt"));
			$payu_key = $this->encrypted->processValue($this->getConfigData("merchant_key"));

			$hashString = $payu_key . '|' . $txnid . '|' . $amount . '|EXPRESS|' . $firstname . '|' . $email . '|'.$udf1.'||||' . $udf5 . '||||||' . $payu_salt;

			// Calculate the SHA-512 hash using hash_hmac
			$hash = hash ("sha512", $hashString);
            $baseUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
            $webhookUrl=$baseUrl."payu/standard/webhook/";
            $shippingUrl=$baseUrl;
            $customerSession=true;
            if($this->customerSession->isLoggedIn())
                $customerSession=false;

            $emailRequired=true;
            if(!$this->customerSession->isLoggedIn() && $this->getConfig('checkout/options/guest_checkout')==1)
                $emailRequired=false;
        $expressDataArr = [];
			$expressDataArr ['key'] = $payu_key;
			$expressDataArr ['hash'] = $hash;
			$expressDataArr ['txnid'] = $txnid;
			$expressDataArr ['app_version'] = "3.8";
			$expressDataArr ['phone'] = $phone;
			$expressDataArr ['firstname'] = $firstname;
			$expressDataArr ['lastname'] = $lastname;
			$expressDataArr ['email'] = $email;
            $expressDataArr ['platform'] = "magento";
            $expressDataArr ['email_required'] = $emailRequired ;
            $expressDataArr ['edit_email_allowed'] = $customerSession;
            $expressDataArr ['edit_phone_allowed'] = "true" ;
			$expressDataArr ['udf1']   = 'Magento2';
			$expressDataArr ['udf2']   = '';
			$expressDataArr ['udf3']   = '';
			$expressDataArr ['udf4']   = '';
			$expressDataArr ['udf5']   = $udf5;
			$expressDataArr ['drop_category']           = '';
			$expressDataArr ['enforce_paymethod'] = '';
			$expressDataArr ['isCheckoutExpress'] = true;
			$expressDataArr ['icp_source']   = 'express';
			$expressDataArr ['productinfo'] = 'EXPRESS';
			$expressDataArr ['surl']               = $this->getReturnUrl();
            $expressDataArr ['furl']               = $this->getCancelUrl();
            $expressDataArr ['curl']               = $this->getCancelUrl();
			$expressDataArr ['orderid']        = substr(str_shuffle(sha1(microtime())), 0, 5);
			$expressDataArr ['cart_details'] = $cartDetail;
            $expressDataArr ['custom_note'] = "";
            $expressDataArr ['extra_charges']['totalAmount'] = NULL;
            $expressDataArr ['extra_charges']['shipping_charges'] =null; // this amount adding extra charges + cart Amount
            $expressDataArr ['extra_charges']['cod_fee'] =0; // this amount adding extra charges + cart Amount
            $expressDataArr ['extra_charges']['other_charges'] =NULL; // this amount adding extra charges + cart Amount
            $expressDataArr ['extra_charges']['tax_info'] =NULL; // this amount adding extra charges + cart Amount
			if($this->getFetchDynamicCharges()){
				$expressDataArr ['fetch_dynamic_charges'] = true;
				$expressDataArr ['amount'] = $amount;
			}else{
				$expressDataArr ['fetch_dynamic_charges'] = false;


				$tax_amount = strval($this->checkoutSession->getQuote()->getShippingAddress()->getData('tax_amount'));
				
				$tax_info = array(
                        'breakup'=>array( 
                            	'Standard' => $tax_amount
                        	),
                        'total'=> strval($tax_amount)
                 );

				$expressDataArr ['extra_charges']['tax_info'] =$tax_info; // this amount adding
				$expressDataArr ['amount'] = $amount+$this->checkoutSession->getQuote()->getShippingAddress()->getData('tax_amount');
			}

			
            $expressDataArr ['dynamic_charges_endpoint']= $shippingUrl;
            $expressDataArr ['partner_webhook_success'] = $webhookUrl;
            $expressDataArr ['partner_webhook_failure'] = $webhookUrl;

			$data_array_json = json_encode($expressDataArr,JSON_UNESCAPED_SLASHES);

			$writer = new \Zend_Log_Writer_Stream(BP . '/var/log/payu2.log'); 
			$logger = new \Zend_Log(); 
			$logger->addWriter($writer); 
			$logger->info('Express Data Arr');
			$logger->info(json_encode($expressDataArr));



            $v2hash = hash ('sha512', $data_array_json ."|".$c_date."|".$payu_salt);
			$username  =  "hmac username=\"$payu_key\"";
			$algorithm  =  "algorithm=\"sha512\"";
			$headers     =  "headers=\"$c_date\"";
			$signature   =  "signature=\"$v2hash\"";

			$auth_header_string = $username . ', ' . $algorithm . ', ' . $headers . ', ' . $signature;

			return [
				'v2Hash' => $auth_header_string,
				'expressData' => $expressDataArr,
				'data' => $data_array_json,
				'date' => $c_date
			];
	}

    public function generatePayuHash($txnid, $amount, $productInfo, $name,
            $email,$udf1,$udf5) {
        $SALT = $this->encrypted->processValue($this->getConfigData('salt'));

        $posted = array(
            'key' => $this->encrypted->processValue($this->getConfigData("merchant_key")),
            'txnid' => $txnid,
            'amount' => $amount,
            'productinfo' => $productInfo,
            'firstname' => $name,
            'email' => $email,
			'udf1' => $udf1,
			'udf5' => $udf5,
        );

        $hashSequence = 'key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10';

        $hashVarsSeq = explode('|', $hashSequence);
        $hash_string = '';
        foreach ($hashVarsSeq as $hash_var) {
            $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
            $hash_string .= '|';
        }
        $hash_string .= $SALT;

        return strtolower(hash('sha512', $hash_string));
    }

    //validate response
    public function validateResponse($returnParams) {

		if ($returnParams['status'] != 'success') {
            return false;
        }
        if ($returnParams['key'] != $this->encrypted->processValue($this->getConfigData("merchant_key"))) {
            return false;
        }

		//validate hash
		if(isset($returnParams['hash'])){
			$txnid 			= $returnParams['txnid'];
			$amount        	= $returnParams['amount'];
			$productinfo   	= $returnParams['productinfo'];
			$firstname     	= $returnParams['firstname'];;
			$email         	= $returnParams['email'];
			$Udf1 			= $returnParams['udf1'];
			$Udf2 			= $returnParams['udf2'];
		 	$Udf3 			= $returnParams['udf3'];
		 	$Udf4 			= $returnParams['udf4'];
		 	$Udf5 			= $returnParams['udf5'];
		 	$Udf6 			= $returnParams['udf6'];
		 	$Udf7 			= $returnParams['udf7'];
		 	$Udf8 			= $returnParams['udf8'];
		 	$Udf9 			= $returnParams['udf9'];
		 	$Udf10 			= $returnParams['udf10'];
			$additionalCharges 	= 	0;
			if (isset($returnParams["additionalCharges"])) $additionalCharges = $returnParams['additionalCharges'];

			$keyString =  $this->encrypted->processValue($this->getConfigData("merchant_key")).'|'.$txnid.'|'.$amount.'|'.$productinfo.'|'.$firstname.'|'.$email.'|'.$Udf1.'|'.$Udf2.'|'.$Udf3.'|'.$Udf4.'|'.$Udf5.'|'.$Udf6.'|'.$Udf7.'|'.$Udf8.'|'.$Udf9.'|'.$Udf10;

			$keyArray = explode("|",$keyString);
			$reverseKeyArray = array_reverse($keyArray);
			$reverseKeyString=implode("|",$reverseKeyArray);
			$status=$returnParams['status'];
			$saltString     = $this->encrypted->processValue($this->getConfigData('salt')).'|'.$status.'|'.$reverseKeyString;
			if($additionalCharges > 0)
				$saltString     = $additionalCharges.'|'.$saltString;

			$sentHashString = strtolower(hash('sha512', $saltString));

			if($sentHashString != $returnParams['hash'])
				return false;
			else
				return true;
		}
        return false;
    }

    public function postProcessing(\Magento\Sales\Model\Order $order,\Magento\Framework\DataObject $payment, $response)
	{
		$writer = new \Zend_Log_Writer_Stream(BP . '/var/log/payu.log'); 
		$logger = new \Zend_Log(); 
		$logger->addWriter($writer); 
		$logger->info('Custom message');
		$logger->info('order id ' . json_encode($order->getIncrementId()));
		$logger->info('response '.json_encode($response));
		try {
			$orderemail = $this->getConfigData("orderemail");
			$geninvoice = $this->getConfigData("generateinvoice");
			$emailinvoice = $this->getConfigData("invoiceemail");


			if($this->verifyPayment($order,$response['txnid']))
			{

				$payu_id = $response['mihpayid'];
                if(isset($response['field3'])){
                    if(!empty($response['field3'])){
                        $payu_id=$response['field3'];
                    }
                }
				$payment->setTransactionId($payu_id)
				->setPreparedMessage('SUCCESS')
				->setShouldCloseParentTransaction(true)
				->setIsTransactionClosed(0)
				->setAdditionalInformation('payu_txnid', $response['txnid'])
				->setAdditionalInformation('payu_mihpayid', $payu_id)
				->setAdditionalInformation('payu_order_status', 'approved');

				If (isset($response['additionalCharges'])) {
					$payment->setAdditionalInformation('Additional Charges', $response['additionalCharges']);
					$payment->registerCaptureNotification(($response['amount']-$response['discount'])+$response['additionalCharges'],true);
				}
				else {
					$payment->registerCaptureNotification(($response['amount']-$response['discount']),true);
				}

				if($this->getConfigData('debuglog')==true)
					$this->logger->debug($response);

				$order->setTotalPaid($response['amount']);
				$order->setState(Order::STATE_PROCESSING,true)->setStatus(Order::STATE_PROCESSING);
				$order->setCanSendNewEmailFlag(true);
				$order->setIsCustomerNotified(true)->save();

				if($orderemail)
					$this->orderSender->send($order);

				if($geninvoice && $order->canInvoice()) {
					$invoice = $order->prepareInvoice();
					$invoice->register();
					$invoice->save();

					if($emailinvoice) {
						$objManager = \Magento\Framework\App\ObjectManager::getInstance();
						$sender = $objManager->get('\Magento\Sales\Model\Order\Email\Sender\InvoiceSender');
						$sender->send($invoice);
					}
				}


			}
			else {
				//modified to cancel order in case of failed or canceled payment
				if($this->getConfigData('debuglog')==true)
					$this->logger->debug($response);

				$order->setState(Order::STATE_CANCELED,true)->setStatus(Order::STATE_CANCELED);
				$order->save();
			}
		}
		catch(LocalizedException $e){
			if($this->getConfigData('debuglog')==true)
				$this->logger->debug([$e->getMessage()]);
		}
    }

	public function verifyPayment(\Magento\Sales\Model\Order $order,$txnid)
	{
		$flag = $this->getConfigData('verifypayment');

		if(!$flag) return true;

		$fields = array(
				'key' => $this->encrypted->processValue($this->getConfigData("merchant_key")),
				'command' => 'verify_payment',
				'var1' => $txnid,
				'hash' => ''
			);

		$hash = hash("sha512", $fields['key'].'|'.$fields['command'].'|'.$fields['var1'].'|'.$this->encrypted->processValue($this->getConfigData('salt')));
		$fields['hash'] = $hash;
		$fields_string = http_build_query($fields);
		$url = 'https://info.payu.in/merchant/postservice.php?form=2';
		if( $this->getConfigData('environment') == 'sandbox' )
			$url = "https://test.payu.in/merchant/postservice.php?form=2";


		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_CAINFO,self::$certificate_path );
		curl_setopt($curl, CURLOPT_SSLVERSION, 6);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 60);
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
		$response = curl_exec($curl);
		$curlerr = curl_error($curl);

		$message = '';
		$res ='';
		if($curlerr !=''){
			$message = $curlerr;
			return false;
		}
		else
		{
			$res = json_decode($response,true);

			if($this->getConfigData('debuglog')==true)
				$this->_logger->debug("Verify response: ".$response);

			if(!isset($res['status']))
				$message = $res['msg'];
			else{
				$res = $res['transaction_details'];
				$res = $res[$txnid];
			}
//            && $res['transaction_amount'] >= round($order->getBaseGrandTotal(), 2)
			if($res['status'] == 'success' )
			{
				return true;
			}
			else return false;
		}
	}


 /**
     * Refunds specified amount
     *
     * @param InfoInterface $payment
     * @param float $amount
     * @return $this
     * @throws LocalizedException
     */
	public function refund(InfoInterface $payment, $amount)
    {

		// echo "<pre>";print_r($payment->debug());exit;
		$addData=$payment->getAdditionalInformation();
		$txnid='';
		if(isset($addData['method_title'])&& $addData['method_title']=="PayU"){

			if(isset($addData['payu_mihpayid']))
				$txnid=$addData['payu_mihpayid'];

			$url = 'https://info.payu.in/merchant/postservice.php?form=2';
			if( $this->getConfigData('environment') == 'sandbox' )
				$url = "https://test.payu.in/merchant/postservice.php?form=2";

				$fields = array(
					'key' => $this->encrypted->processValue($this->getConfigData("merchant_key")),
					'command' => 'cancel_refund_transaction',
					'var1' => $txnid,
					'var2' =>uniqid().'-'.time(),
					'var3' =>$amount
				);

			$hash = hash("sha512", $fields['key'].'|'.$fields['command'].'|'.$fields['var1'].'|'.$this->encrypted->processValue($this->getConfigData('salt')));
			$fields['hash'] = $hash;
			$fields_string = http_build_query($fields);
			// curl Execution
			$response=$this->refundHelper->curlExecute($url,$fields_string);
			$res=json_decode($response);
			//echo $response;die;
			if($res->error_code==100 || $res->error_code==101 || $res->error_code==102 ){
				$this->refundHelper->setRefundData($payment,$response);
				return $this;
			}else{
				throw new LocalizedException(__($res->msg));
			}
		}
    }


	//Additional coding in case requirement comes
	public function cancelOrder(\Magento\Sales\Model\Order $order)
	{
		try
		{
			$orderId=$order->getId();

			if($order->canCancel())
			{
				$order->setTotalPaid(0);
				$order->setState(Order::STATE_CANCELED,true)->setStatus(Order::STATE_CANCELED);
				$order->save();
			}

			if($this->getConfigData('debuglog')==true)
				$this->logger->debug(array("Order Canceled-".$orderId));

			return true;
		}
		catch(LocalizedException $e){
			if($this->getConfigData('debuglog')==true)
				$this->logger->debug([$e->getMessage()]);
			return false;
		}
	}

	public function getUrl($value = null){
		$baseUrl=$this->storeManager->getStore()->getBaseUrl();
		return $baseUrl.$value;
	}

    public function getConfig($path)
    {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
