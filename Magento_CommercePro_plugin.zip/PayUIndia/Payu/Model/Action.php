<?php

namespace PayUIndia\Payu\Model;


class Action implements \Magento\Framework\Option\ArrayInterface
{
    const ACTION_EXPRESS    	= 'expresscheckout';
    const ACTION_REDIRECT  	= 'redirect';
    const ACTION_BOLT               = 'bolt';

    /**
     * Possible action types
     * 
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::ACTION_EXPRESS,
                'label' => 'Express Checkout',
            ],
			[
                'value' => self::ACTION_BOLT,
                'label' => 'BOLT',
            ],
            [
                'value' => self::ACTION_REDIRECT,
                'label' => 'Redirect'
            ]
        ];
    }
}
