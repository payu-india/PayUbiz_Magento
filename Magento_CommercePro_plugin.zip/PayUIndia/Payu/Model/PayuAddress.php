<?php

namespace PayUIndia\Payu\Model;

class PayuAddress
{
    protected $payuHelper;
    protected $countryFactory;
    protected $addressRepository;
    protected $address;
    protected $customerModel;
    protected $regionCollection;
    protected $customerSession;
    protected $encrypted;

    public function __construct(
        \PayUIndia\Payu\Helper\Payu $payuHelper,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        \Magento\Customer\Model\Customer $customerModel,
        \Magento\Customer\Model\ResourceModel\AddressRepository $addressRepository,
        \Magento\Customer\Model\Address $address,
        \Magento\Directory\Model\ResourceModel\Region\Collection $regionCollection,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Config\Model\Config\Backend\Encrypted $encrypted
    )
    {
        $this->payuHelper = $payuHelper;
        $this->countryFactory = $countryFactory;
        $this->customerModel = $customerModel;
        $this->addressRepository = $addressRepository;
        $this->address = $address;
        $this->regionCollection = $regionCollection;
        $this->customerSession = $customerSession;
        $this->encrypted = $encrypted;
    }

    public function token($scope)
    {
        return true;

    }
    public function saveAddress($address,$customerData)
    {
       return true;
    }
    public function getCountryName($countryId): string
    {
        $countryName = '';
        $country = $this->countryFactory->create()->loadByCode($countryId);
        if ($country) {
            $countryName = $country->getName();
        }
        return $countryName;
    }

    public function updateAddress($address)
    {
        return true;
    }
    public function prepareShippingAddress($address,$email)
    {
        $region=$this->regionData($address->getRegionId());
        $addressData=[
            "name"=> $address->getFirstname().' '.$address->getLastname(),
            "email"=> $email,
            "addressLine"=>implode(" ",$address->getStreet()),
            "addressLine2"=> " ",
            "addressPhoneNumber"=>$address->getTelephone(),
            "houseNumber"=> "",
            "landmark"=> "",
            "locality"=> "",
            "subLocality"=> "",
            "street"=> "",
            "village"=> "",
            "pincode"=> $address->getPostcode(),
            "city"=> $address->getCity(),
            "state"=> $region,
            "country"=> $this->getCountryName($address->getCountryId()),
            "tag"=> "Home",
            "source"=> "magento",
            "isDefault"=> true
        ];
        return $addressData;
    }

    public function logger($post)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/address.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info($post);
    }

    public function regionData($regionId)
    {
        $region=$this->regionCollection->addFieldToFilter('rname.region_id',$regionId);
        return $region->getFirstItem()->getName();
    }
    public function deleteAddress($customerAddress)
    {
       return true;

    }
    public function syncAddressBeforePayment()
    {
        $customer = $this->customerSession->getCustomer();
        if($customer) {
            foreach ($customer->getAddresses() as $address) {
                if (!$address->getPayuAddressId()) {
                    $this->saveAddress($address,$customer);
                }else{
                    $this->updateAddress($address);
                }
            }
        }
    }
}
