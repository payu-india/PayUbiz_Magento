<?php

namespace PayUIndia\Payu\Model;

use _PHPStan_39fe102d2\Nette\PhpGenerator\Factory;
use PayUIndia\Payu\Api\ShippingMethodInterface;
use function MongoDB\BSON\toRelaxedExtendedJSON;
use Magento\Framework\Webapi\Exception as WebapiException;
use Psr\Log\LoggerInterface;

class ShippingMethod implements ShippingMethodInterface
{
    protected $request;
    protected $curl;
    protected $countryFactory;
    protected $maskedQuoteIdToQuoteId;
    protected $storeManager;
    protected $jsonEncoder;
    protected $collection;
    protected $date;
    protected $responseCode;
    protected $json;
    protected $quoteRepository;
    protected $logger;

    protected static $certificate_path = __DIR__ . '/../certificates/cacert.pem';


    public function __construct(
        \Magento\Framework\App\RequestInterface $request,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        \Magento\Quote\Model\MaskedQuoteIdToQuoteId $maskedQuoteIdToQuoteId,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Json\EncoderInterface $jsonEncoder,
        \PayUIndia\Payu\Model\ResourceModel\PayuAuth\Collection $collection,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $date,
        \Magento\Framework\HTTP\PhpEnvironment\Response $responseCode,
        \Magento\Framework\Serialize\Serializer\Json $json,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        LoggerInterface $logger

    ) {
        $this->request = $request;
        $this->curl = $curl;
        $this->countryFactory = $countryFactory;
        $this->maskedQuoteIdToQuoteId = $maskedQuoteIdToQuoteId;
        $this->storeManager = $storeManager;
        $this->jsonEncoder = $jsonEncoder;
        $this->collection = $collection;
        $this->date = $date;
        $this->responseCode = $responseCode;
        $this->json=$json;
        $this->quoteRepository=$quoteRepository;
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/shippingapi.log');
        $this->logger = new \Zend_Log();
        $this->logger->addWriter($writer);
    }
    public function getShippingMethods()
    {
        $header=$this->request->getHeader('Authorization');
        $result = $this->curl->getBody();
        $baseUrl = $this->storeManager->getStore()->getBaseUrl();
        $storeCode=$this->storeManager->getStore()->getCode();
        $paramsData=json_decode($this->request->getContent());
        $address=$paramsData->address;
        $status = 'fail';
        $message = "Invalid Token";
        $shippingData = NULL;
        $txnid=explode('-',$paramsData->txnid);
        $quote_id=$txnid[0];
        $parentQuote = $this->quoteRepository->get($quote_id);
        $parentQuote->setIsActive(true)->save();
        if($header){
            $header=explode(" ",$header);
            $authCollection=$this->collection->addFieldToFilter('token',$header[1])->getFirstItem();
            $currentDateTime = $this->date->date()->format('Y-m-d H:i:s');
            if($header[1]!==$authCollection->getToken() || $currentDateTime>$authCollection->getExpiredAt()){
                $status = 'fail';
                $message = "Invalid Token";
                $this->responseCode->clearHeaders()->setHttpResponseCode(\Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED)->sendResponse();
                $shippingData = NULL;
            }else{

                $url=$baseUrl."rest/".$storeCode."/V1/carts/".$quote_id."/OMestimate-shipping-methods";
                $street=wordwrap($address->address_1, 30, ",");
                $add = json_encode(explode(',',$street));
                $state=$address->state;
                if ($state=='Dadra & Nagar Haveli & Daman & Diu'){
                    $state='Dadra and Nagar Haveli';
                }elseif ($state=='Jammu & Kashmir') {
                    $state='Jammu and Kashmir';
                }
                elseif ($state=='Andaman & Nicobar Islands') {
                    $state='Andaman and Nicobar Islands';
                }else{}

                $raw='{
                    "address": {
                        "street": '.$add.',
                        "city": "'.$address->city.'",
                        "region": "'.$state.'",
                        "country_id": "'.$address->country.'",
                        "postcode": '.$address->postcode.'
                    }
                }';
                $response=$this->getCurl($url,$raw);
                $this->logger->info("estimate shipping method : ".$response);
                $shippingData = json_decode($response);
                if(isset($shippingData->message))
                {
                    $status = 'fail';
                    $message = $shippingData->message;
                    $this->responseCode->clearHeaders()->setHttpResponseCode(\Magento\Framework\Webapi\Exception::HTTP_INTERNAL_ERROR)->sendResponse();
                    $shippingData = NULL;
                }
                else{
                    $status = 'success';
                    $message = __("Shipping methods fetched successfully.");
                    $shippingMethods=json_decode($response,true);
                    $i=0;
                    $data=[];
                    foreach ($shippingMethods as $shippingMethod)
                    {
                        $info=$this->getShippingInfo($shippingMethod,$paramsData);
                        $data[$i]['carrier_code'] = $shippingMethod['carrier_code'];
                        $data[$i]['method_code'] = $shippingMethod['method_code'];
                        $data[$i]['carrier_title'] = $shippingMethod['carrier_title'];
                        $data[$i]['amount'] = $shippingMethod['amount'];
                        $data[$i]['error_message'] = $shippingMethod['error_message'];
                        $data[$i]['tax_price'] = $info['tax'];
                        $data[$i]['subtotal'] = $info['subtotal'];
                        $data[$i]['grand_total'] = $info['grand_total'];

                        $i++;
                    }
                    $shippingData=json_decode(json_encode($data,true));
                }
            }
        }else{
            $status = 'fail';
            $message = 'Token Required';
            $this->responseCode->clearHeaders()->setHttpResponseCode(\Magento\Framework\Webapi\Exception::HTTP_UNAUTHORIZED)->sendResponse();
            $shippingData = NULL;
        }
        $parentQuote->setIsActive(false)->save();
        echo $this->getResponseJson($shippingData,$status,$message);
        die;
    }

    public function getShippingInfo($carrier,$paramsData){

        $result = $this->curl->getBody();
        $baseUrl = $this->storeManager->getStore()->getBaseUrl();
        $storeCode=$this->storeManager->getStore()->getCode();
        $address=$paramsData->address;

        $txnid=explode('-',$paramsData->txnid);
        $quote_id=$txnid[0];
        $url=$baseUrl."rest/".$storeCode."/V1/carts/".$quote_id."/OMshipping-information";
        $street=wordwrap($address->address_1, 30, ",");
        $streetData = json_encode(explode(',',$street));

        $add = '{
                "street": '.$streetData.',
                "city": "'.$address->city.'",
                "region": "'.$address->state.'",
                "country_id": "'.$address->country.'",
                "postcode": '.$address->postcode.'
            }';
        $raw='{
            "addressInformation": {
                "shipping_address": '.$add.',
                "billing_address": '.$add.',
                "shipping_method_code": "'.$carrier['method_code'].'",
                "shipping_carrier_code": "'.$carrier['carrier_code'].'",
                "extension_attributes": {}
            }
        }';
        $response=$this->getCurl($url,$raw);
        $this->logger->info("shipping info: ".$response);
        $shippingInfo = json_decode($response);
        if(isset($shippingInfo->message))
        {
            $status = 'fail';
            $message = $shippingInfo->message;
            $shippingData = NULL;
            $result = $this->getResponseJson($shippingData,$status,$message);
            echo $result;
            die;
        }
        else {
            $responseData = json_decode($response, true);
            $data['tax']=$responseData['totals']['tax_amount'];
            $data['subtotal']=$responseData['totals']['subtotal'];
            $data['grand_total']=$responseData['totals']['grand_total'];
            return $data;
        }
    }

    public function getResponseJson($result,$status="",$message="")
    {
        $data["status"]=$status;
        $data["message"]=$message;
        $data["data"]= $result;
        return $this->jsonEncoder->encode($data);
    }
    public function getCurl($url,$raw)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CAINFO,self::$certificate_path );
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $raw);
        $headers=array('Content-Type: application/json');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $response = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return $response;
    }

    public function getShippingMethodsForOrder($params)
    {
        $baseUrl = $this->storeManager->getStore()->getBaseUrl();
        $storeCode=$this->storeManager->getStore()->getCode();
        $txnid=explode('-',$params['txnid']);
        $quote_id=$txnid[0];
        $parentQuote = $this->quoteRepository->get($quote_id);
        $parentQuote->setIsActive(true)->save();
        // Preparing Data
        $streetData=isset($params['shipping_address']['addressLine'])?$params['shipping_address']['addressLine']:$params['address1'].' '.$params['address2'];

        $streetData=isset($params['shipping_address']['addressLine2'])?$streetData.' '.$params['shipping_address']['addressLine2']:"";

        $street=wordwrap($streetData, 30, ",");
        $name=explode(' ',isset($params['shipping_address']['name'])?$params['shipping_address']['name']:$params['firstname']);
        $fname=$name[0];
        $lname=isset($name[1])?$name[1]:$params['lastname'];
        $add = json_encode(explode(',',$street));
        $firstname = isset($fname)?$fname:'New';
        $lastname = isset($lname)?$lname:'user';
        $email = isset($params['shipping_address']['email'])?$params['shipping_address']['email']:$params['email'];
        $city = isset($params['shipping_address']['city'])?$params['shipping_address']['city']:$params['city'];
        $country_id = isset($params['shipping_address']['country'])?$params['shipping_address']['country']:'IN';
        $region = isset($params['shipping_address']['state'])?$params['shipping_address']['state']:$params['state'];
        $postcode = isset($params['shipping_address']['pincode'])?$params['shipping_address']['pincode']:$params['zipcode'];
        $telephone = isset($params['shipping_address']['addressPhoneNumber'])?$params['shipping_address']['addressPhoneNumber']:$params['phone'];
        $fax = '';

        $raw='{
            "address": {
                "firstname" : "'.$firstname.'",
                "lastname":"'.$lastname.'",
                "street" :'.$add.',
                "email" :"'.$email.'",
                "city": "'.$city.'",
                "country_id": "'.$country_id.'",
                "region" : "'.$region.'",
                "postcode":"'.$postcode.'",
                "telephone" : "'.$telephone.'",
                "fax" : "'.$fax.'",
                "save_in_address_book" : 0
            }
        }';
        $url=$baseUrl."rest/".$storeCode."/V1/carts/".$quote_id."/OMestimate-shipping-methods";
        $response=$this->getCurl($url,$raw);
        $shippingData = json_decode($response);
        $extraCharges=$params['extra_charges'];

        foreach ($shippingData as $shippingMethod) {

            if ($shippingMethod->carrier_code == $extraCharges['carrier_code']){
                return $shippingMethod;
            }
        }
        return 0;
    }

}
