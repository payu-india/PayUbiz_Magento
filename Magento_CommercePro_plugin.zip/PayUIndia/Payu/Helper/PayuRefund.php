<?php

namespace PayUIndia\Payu\Helper;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Config\ScopeConfigInterface;


class PayuRefund
{
    protected $payuRefundFactory;
    protected $logger;
    protected $scopeConfig;


    public function __construct(
        \PayUIndia\Payu\Model\PayuRefundFactory $payuRefundFactory,
        \Magento\Payment\Model\Method\Logger $logger,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->payuRefundFactory = $payuRefundFactory;
        $this->logger = $logger;
        $this->scopeConfig = $scopeConfig;

    }

    public function setRefundData($payment, $response)
    {
        try {
            $creditMemo = $payment->getCreditmemo();
            $addInfo = $payment->getAdditionalInformation();
            $invoice = $creditMemo->getInvoice();
            $responseData = json_decode($response);
            $RefundModel = $this->payuRefundFactory->create();

            if ($responseData->status != 0) {
                $data = [
                    "order_id" => $creditMemo->getOrderId(),
                    "request_id" => $addInfo['payu_txnid'],
                    "mihpayid" => $payment->getTransactionId(),
                    "total_amount" => $invoice['grand_total'],
                    "refunded_amount" => $invoice['base_total_refunded'],
                    "refund_txn_id" => $responseData->request_id,
                    "status_code" => $responseData->error_code,
                    "status" => $responseData->msg,
                    "response" => $response
                ];

                $RefundModel->setData($data);
                $RefundModel->save();
            } else {
                throw new LocalizedException(__($responseData->msg));
            }
        } catch (\Throwable $th) {

            throw new LocalizedException(__($th));
        }
    }
    public function curlExecute($url,$fields_string)
    {
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $fields_string,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/x-www-form-urlencoded'
        ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;
    }
    public function getConfigData($value)
    {
        return $this->scopeConfig->getValue(
            'payment/payu/' . $value,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
