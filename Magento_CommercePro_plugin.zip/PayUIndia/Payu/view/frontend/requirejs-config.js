var config = {
    map: {
        '*': {
          'Magento_Checkout/template/minicart/content.html': 
              'PayUIndia_Payu/template/minicart/content.html'
        }
  },
    config: {
        mixins: {
            'Magento_Checkout/js/view/minicart': {
                'PayUIndia_Payu/js/view/minicart-mixin': true
            }
        }
    }
};