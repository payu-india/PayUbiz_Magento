***********************************************************************
*                                                                     *
*             PayUBiz Express for Magento v2.4.6 Extension            *
*                                                                     *
***********************************************************************

This extension supports Web Browser security update for cross-site request forgery (CSRF).

Note: For Redirect feature "SameSite=None; Secure" setting is mandatory at server level.

Added Features:


-Minimum dependency on Samesite attribute
-CSRF validation issue fixes.
-To avoid same transaction id issue on payment gateway we use unique txnid.
-Create order in pending_payment status before opening Express popup.
-Create a order attribute (txnid) - it will be used to reconcile order if customer paid but order status is still pending_payment.
-Sync Magento customer Address at PayU
-Verify payment using PayU inquiry API
-Verify payment issue fixes with offer data.
-Payu Offer data reconciliation on successful response or using cron.
-Send new order notification after receiving payment confirmation. (Read notes for email configuration)
-Send invoice email after generation of new invoice.
-Fix for order number not displayed on Onepage/Success
-Fix for Guest checkout - Email address validation in core Magento 2
-Invoice generation after receiving payment confirmation.
-Stop triggering of the email while order creation in pending_payment status and add email trigger post-successful reconciliation.
-Added cron (scheduler) to check all pending payment orders and reconcile order based on txnid using verify_payment API.


Pre-requisite:

- Magento 2.4.6 installation (both frontend and admin) must be running on HTTPS.
- CSP module must be enabled


Steps To Install PayU payment extension:

1. Take a full backup of existing Magento 2.4.6 (both code and database)

2. If previously installed, disable PayU payment extension.

3. Uninstall / Remove physical extension files from app/code/PayUIndia

4. Upload present extension files to Magento <app>/<code>.

5. upgrade and deploy Magento installation.

6. Login to Admin panel and enable payment extension.


Extension Configuration -

1. Enable
    Yes – PayU will work.
    No – PayU will not work.

2. Payment Type
    Express Checkout – If admin selects this option, an end-user will redirect to the payment page. It this case, does not ask the address, payment method.

3. Enable webhook
    Yes
    No

4. Payment Action
    Authorize Only
    Authorize and capture (We can capture the status transaction)

5. Send order email
    Yes
    No

6. Generate invoice
    Yes
    No

7. Send invoice email (To notify the customer)
    Yes
    No

8. Environment	 	- Sandbox :: for Test transaction
			- Production :: for live transaction
9. Merchant Key		- As provided by PayU

10. Salt Key		- As provided by PayU

11. Account type
    PayUBiz (For Indian Only)

12. Merchant ID
    This is unique merchant ID

13. Enable payment verification
    Yes
    No

14.Enable Debug Log
    Yes
    No

Configure New Order Email sender -
** perform this step to send new order notification only after processing of captured payment.
