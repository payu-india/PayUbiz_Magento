define([
    'uiComponent',
    'Magento_Customer/js/customer-data',
    'jquery',
    'ko',
    'underscore',
    'sidebar',
    'mage/translate',
    'mage/dropdown'
], function (Component, customerData, $, ko, _) {
    'use strict';

    var mixin = {
        isButtonEnable: function () {
            
            /*You can add your condition here based on your requirements.*/
            console.log(window.checkout.isExpressCheckout);
            return window.checkout.isExpressCheckout;
        },
        preparePaymentHtml: function () {
            console.log("hello");
            jQuery(function($) {
                $.ajax({
                    //url: url.build('payu/checkout/redirect'),
                    url: window.checkout.payURedirectUrl,
                    type: 'get',
                    dataType: 'json',
                    showLoader:true,
                    cache: false,
                    processData: false, // Don't process the files
                    contentType: false, // Set content type to false as jQuery will tell the server its a query string request
                    success: function (data) {
                        $("#payuloader",parent.document).html(data['html']);
                        //alert(data['html']);
                    },
                    error: function(xhr, ajaxOptions, thrownError) {
                        alert(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                    }
                });
            });
        }
    };

    return function (target) {
        return target.extend(mixin);
    };
});
