<?php

namespace PayUIndia\Payu\Model;

use Magento\Authorization\Model\UserContextInterface;
use Magento\Quote\Api\ChangeQuoteControlInterface;
use Magento\Quote\Api\Data\CartInterface;

class ChangeQuoteControl implements ChangeQuoteControlInterface
{
    /**
     * @var UserContextInterface
     */
    private $userContext;

    protected $helper;

    /**
     * @param UserContextInterface $userContext
     */
    public function __construct(
        UserContextInterface $userContext,
        \PayUIndia\Payu\Helper\Payu $helper
    )
    {
        $this->userContext = $userContext;
        $this->helper = $helper;
    }

    /**
     * @inheritdoc
     */
    public function isAllowed(CartInterface $quote): bool
    {
        if($this->helper->getConfigData('active')&&$this->helper->getConfigData('paymentaction')=="expresscheckout")
            return true;
        else {
            switch ($this->userContext->getUserType()) {
                case UserContextInterface::USER_TYPE_CUSTOMER:
                    return ($quote->getCustomerId() == $this->userContext->getUserId());
                case UserContextInterface::USER_TYPE_GUEST:
                    return ($quote->getCustomerId() === null);
                case UserContextInterface::USER_TYPE_ADMIN:
                case UserContextInterface::USER_TYPE_INTEGRATION:
                    return true;
            }
        }

        return false;
    }
}
