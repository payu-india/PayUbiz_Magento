<?php

namespace PayUIndia\Payu\Model\ResourceModel\PayuEventLog;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use PayUIndia\Payu\Model\PayuEventLog as Model;
use PayUIndia\Payu\Model\ResourceModel\PayuEventLog as ResourceModel;

class Collection extends AbstractCollection
{
    protected function _construct()
    {
        $this->_init(Model::class, ResourceModel::class);
    }
}
