<?php

namespace PayUIndia\Payu\Model;

class PayuAddress
{
    protected $payuHelper;
    protected $countryFactory;
    protected $addressRepository;
    protected $address;
    protected $customerModel;
    protected $regionCollection;
    protected $customerSession;
    protected $encrypted;

    public function __construct(
        \PayUIndia\Payu\Helper\Payu $payuHelper,
        \Magento\Directory\Model\CountryFactory $countryFactory,
        \Magento\Customer\Model\Customer $customerModel,
        \Magento\Customer\Model\ResourceModel\AddressRepository $addressRepository,
        \Magento\Customer\Model\Address $address,
        \Magento\Directory\Model\ResourceModel\Region\Collection $regionCollection,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Config\Model\Config\Backend\Encrypted $encrypted
    )
    {
        $this->payuHelper = $payuHelper;
        $this->countryFactory = $countryFactory;
        $this->customerModel = $customerModel;
        $this->addressRepository = $addressRepository;
        $this->address = $address;
        $this->regionCollection = $regionCollection;
        $this->customerSession = $customerSession;
        $this->encrypted = $encrypted;
    }

    public function token($scope)
    {
        $fields = [
//            'client_id' => $this->payuHelper->getConfigData("merchant_key"),
//            'client_secret' => $this->payuHelper->getConfigData("salt"),
            'client_id' => '68b9ee63744ba405dc4a013ec9a80d4f9eef4a859c9f04468ddec5c1a35f33f3',
            'client_secret' => '98930aa1b9e717009d51b3492bf635659d3bd95b08e0d243aae23b2df5efa7e2',
            'grant_type' => 'client_credentials',
            'scope' => $scope
        ];
        $fields_string = http_build_query($fields);
        $url= 'https://uat-accounts.payu.in/oauth/token';
        if ($this->payuHelper->getConfigData('environment')=='sandbox')
            $url= 'https://uat-accounts.payu.in/oauth/token';


        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $fields_string,
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/x-www-form-urlencoded'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        return $response;

    }
    public function saveAddress($address,$customerData)
    {
        $url = 'https://apitest.payu.in/user/address/v3';
        if ($this->payuHelper->getConfigData('environment') == 'sandbox')
            $url = 'https://apitest.payu.in/user/address/v3';
        $merchantKey=$this->encrypted->processValue($this->payuHelper->getConfigData("merchant_key"));
        $tokenData = $this->token('client_save_user_address');
        $tokenData = \Safe\json_decode($tokenData, true);
        $token = $tokenData['access_token'];
        $customerPhoneNumber = $customerData->getPayuPhoneNumber();
        $email = $customerData->getEmail();

        $postData = [
            //"merchantId" => $this->payuHelper->getConfigData("merchant_id"),
            'email' =>$email,
            "shippingAddress" => $this->prepareShippingAddress($address, $email)
        ];
        $this->logger('save Address request =>'.json_encode($postData));
        if($email!=''|| $email!=null)
        {
            if (empty($address->getPayuUserId()) || $address->getPayuUserId() == null) {

                $curl = curl_init();

                curl_setopt_array($curl, array(
                    CURLOPT_URL => $url,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => '',
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_TIMEOUT => 0,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => 'POST',
                    CURLOPT_POSTFIELDS => json_encode($postData, true),
                    CURLOPT_HTTPHEADER => array(
                        'Content-Type: application/json',
                        'Authorization: Bearer ' . $token . '',
                        'x-credential-username: '.$merchantKey.''
                    )
                ));
                //        print_r($token);die();

                $response = curl_exec($curl);

                $this->logger('Save Address =>'.$response);
                curl_close($curl);
                $responseData = json_decode($response);
                if ($responseData->status == 1) {
                    $modelAddress = $this->address->load($address->getId());
//                    $addressRepo = $this->addressRepository->getById($address->getId());
                    $modelAddress->setPayuUserId( $responseData->result->userId);
                    $modelAddress->setPayuAddressId( $responseData->result->shippingAddress->id);
                    $modelAddress->save();
                    $this->logger('=======');
                }
            }
        }
    }
    public function getCountryName($countryId): string
    {
        $countryName = '';
        $country = $this->countryFactory->create()->loadByCode($countryId);
        if ($country) {
            $countryName = $country->getName();
        }
        return $countryName;
    }

    public function updateAddress($address)
    {
        $url= 'https://apitest.payu.in/user/address/v3';
        if ($this->payuHelper->getConfigData('environment')=='sandbox')
            $url= 'https://apitest.payu.in/user/address/v3';
        $merchantKey=$this->encrypted->processValue($this->payuHelper->getConfigData("merchant_key"));

        $tokenData=$this->token('client_update_user_address');
        $tokenData=\Safe\json_decode($tokenData,true);
        $token=$tokenData['access_token'];
        $customerData=$this->customerModel->load($address->getCustomerId());
        $customerPhoneNumber=$customerData->getPayuPhoneNumber();
        $email=$customerData->getEmail();
        $customAttribute=$address->getCustomAttribute('payu_user_id');
        $payuAddressId=$address->getCustomAttribute('payu_address_id');
        if($customAttribute){
            $userId=$customAttribute->getValue();
        }else{
            $userId=$address->getPayuUserId();
        }
        if($payuAddressId){
            $addId=$payuAddressId->getValue();
        }else{
            $addId=$address->getPayuAddressId();
        }
        $postData=[
            "userId"=> $userId,
//            "phoneNumber"=> $customerPhoneNumber,
           "email" => $customerData->getEmail(),
            "shippingAddress"=>$this->prepareShippingAddress($address,$email)
        ];
        $postData['shippingAddress']['id']=$addId;
        $this->logger('update Address request =>'.json_encode($postData));
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'PUT',
            CURLOPT_POSTFIELDS =>json_encode($postData),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: Bearer '.$token.'',
                'x-credential-username: '.$merchantKey.''
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        $this->logger('update Address =>'.$response);

    }
    public function prepareShippingAddress($address,$email)
    {
        $region=$this->regionData($address->getRegionId());
        $addressData=[
            "name"=> $address->getFirstname().' '.$address->getLastname(),
            "email"=> $email,
            "addressLine"=>implode(" ",$address->getStreet()),
            "addressLine2"=> " ",
            "addressPhoneNumber"=>$address->getTelephone(),
            "houseNumber"=> "",
            "landmark"=> "",
            "locality"=> "",
            "subLocality"=> "",
            "street"=> "",
            "village"=> "",
            "pincode"=> $address->getPostcode(),
            "city"=> $address->getCity(),
            "state"=> $region,
            "country"=> $this->getCountryName($address->getCountryId()),
            "tag"=> "Home",
            "source"=> "magento",
            "isDefault"=> true
        ];
        return $addressData;
    }

    public function logger($post)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/address.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info($post);
    }

    public function regionData($regionId)
    {
        $region=$this->regionCollection->addFieldToFilter('rname.region_id',$regionId);
        return $region->getFirstItem()->getName();
    }
    public function deleteAddress($customerAddress)
    {
        $customerData=$this->customerModel->load($customerAddress->getCustomerId());
        $customerPhoneNumber=$customerData->getPayuPhoneNumber();
        $email=$customerData->getEmail();
        $payuAddressId=$customerAddress->getCustomAttribute('payu_address_id');
        $tokenData=$this->token('client_delete_user_address');
        $tokenData=\Safe\json_decode($tokenData,true);
        $token=$tokenData['access_token'];

        $url= 'https://apitest.payu.in/user/address/v3';
        if ($this->payuHelper->getConfigData('environment')=='sandbox')
            $url= 'https://apitest.payu.in/user/address/v3';

        if(!empty($payuAddressId)) {

            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url.'/'.$payuAddressId->getValue(),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'DELETE',
                CURLOPT_POSTFIELDS => '{
                 "email":"'.$email.'"
                }',
                CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json',
                    'Authorization: Bearer '.$token.''
                ),
            ));

            $response = curl_exec($curl);
            curl_close($curl);
            $this->logger('delete Address =>'.$response);
        }

    }
    public function syncAddressBeforePayment()
    {
        $customer = $this->customerSession->getCustomer();
        if($customer) {
            foreach ($customer->getAddresses() as $address) {
                if (!$address->getPayuAddressId()) {
                    $this->saveAddress($address,$customer);
                }else{
                    $this->updateAddress($address);
                }
            }
        }
    }
}
