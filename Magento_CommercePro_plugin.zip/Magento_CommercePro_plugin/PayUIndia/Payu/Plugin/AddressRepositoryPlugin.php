<?php
namespace PayUIndia\Payu\Plugin;

use Magento\Customer\Api\Data\AddressInterface;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Framework\Exception\LocalizedException;

class AddressRepositoryPlugin
{
    protected $payuaddress;
    protected $customerModelFactory;
    public function __construct(
        \PayUIndia\Payu\Model\PayuAddress $payuAddress,
        \Magento\Customer\Model\CustomerFactory $customerModelFactory
    )
    {
        $this->payuaddress = $payuAddress;
        $this->customerModelFactory = $customerModelFactory;
    }
    public function afterSave(AddressRepositoryInterface $subject, AddressInterface $result)
    {
        $customAttribute = $result->getCustomAttributes();
        $customerAddress = $result;
        $customerData=$this->customerModelFactory->create()->load($result->getCustomerId());
        if(!empty($customAttribute))
            $this->payuaddress->updateAddress($customerAddress);
        else{
            $this->payuaddress->saveAddress($customerAddress,$customerData);
        }
        return $result;
    }
}
