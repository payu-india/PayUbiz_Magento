Payu-GQL
